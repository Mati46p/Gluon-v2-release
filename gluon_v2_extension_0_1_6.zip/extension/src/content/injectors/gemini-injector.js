// Content scripts DEV_MODE - set to false for production
if (typeof CONTENT_DEV_MODE === 'undefined') {
  var CONTENT_DEV_MODE = false; // Change to false to disable logs
}

// Shared logger for all Gluon content scripts
if (typeof logger === 'undefined') {
  var logger = {
    _log: (level, ...args) => {
      // Don't log anything if not in dev mode, except errors
      if (!CONTENT_DEV_MODE && level !== 'error') {
        return;
      }

      const prefix = '[Gluon Content]';
      switch (level) {
        case 'log':
        case 'success':
          console.log(prefix, ...args);
          break;
        case 'warn':
          console.warn(prefix, ...args);
          break;
        case 'error':
          console.error(prefix, ...args);
          break;
        default:
          console.log(prefix, ...args);
      }
    },
    log: function(...args) { this._log('log', ...args); },
    warn: function(...args) { this._log('warn', ...args); },
    error: function(...args) { this._log('error', ...args); },
    success: function(...args) { this._log('success', '✅', ...args); },
  };
}

// ============================================================================
// Gemini/AI Studio & Claude File Injector
// ============================================================================

logger.log('Universal file injector loaded');

// Detect current platform
const PLATFORM = detectPlatform();

function detectPlatform() {
  const hostname = window.location.hostname;
  if (hostname.includes('claude.ai')) return 'CLAUDE';
  if (hostname.includes('gemini.google.com') || hostname.includes('aistudio.google.com')) return 'GEMINI';
  return 'UNKNOWN';
}

// Listen for file upload requests from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'upload_file_to_gemini') {
    logger.log('Received file upload request:', message.file);
    uploadFileToAI(message.file)
      .then(() => sendResponse({ success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (message.action === 'upload_binary_file_to_ai') {
      logger.log('Received binary file upload request. Payload:', message.payload); 
      
      try {
        const { filename, mimeType, base64Content } = message.payload; // <-- ZMIANA TUTAJ
        let byteCharacters;

        // DODATKOWY BLOK TRY...CATCH WOKÓŁ KRYTYCZNEJ OPERACJI
        try {
          logger.log('Step 1: Decoding Base64...'); 
          byteCharacters = atob(base64Content); // <-- ZMIANA TUTAJ
          logger.log('Step 1 SUCCESS. Decoded length:', byteCharacters.length); 
        } catch (e) {
          logger.error('FATAL: atob() failed!', e); 
          // Rzuć błąd dalej, aby został złapany przez zewnętrzny catch
          throw new Error('Base64 decoding failed. The data might be corrupt.');
        }
        
        logger.log('Step 2: Creating byte array...'); 
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        logger.log('Step 2 SUCCESS.'); 
        
        logger.log('Step 3: Creating Blob and File...'); 
        const blob = new Blob([byteArray], { type: mimeType }); // <-- ZMIANA TUTAJ
        const file = new File([blob], filename, { type: mimeType }); // <-- ZMIANA TUTAJ
        logger.log('Step 3 SUCCESS. File object created:', file); 

        uploadFileToAI({
          filename: file.name,
          content: file,
          type: file.type
        })
        .then(() => sendResponse({ success: true }))
        .catch(err => sendResponse({ success: false, error: err.message }));

      } catch (err) {
        logger.error('Error converting Base64 to File:', err);
        sendResponse({ success: false, error: 'Failed to process binary file data.' });
      }

      return true;
  }
  if (message.action === 'paste_prompt_to_input') {
    logger.log('Received paste prompt request');
    pasteIntoBestInput(message.payload)
      .then(() => sendResponse({ success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // Keep the message channel open for async response
  }
});

/**
 * Universal file upload for both Claude and Gemini
 */
async function uploadFileToAI(fileData) {
  try {
    // Check if content is already a File/Blob object or raw content
    const file = fileData.content instanceof File 
      ? fileData.content
      : new File([fileData.content], fileData.filename, { 
          type: fileData.type || 'text/plain' 
        });
    
    logger.log('File created/prepared:', { 
      name: file.name, 
      size: file.size, 
      type: file.type,
      platform: PLATFORM
    });

    if (PLATFORM === 'CLAUDE') {
      await uploadToClaude(file);
    } else if (PLATFORM === 'GEMINI') {
      await uploadToGemini(file);
    } else {
      throw new Error('Unsupported platform');
    }
    
    logger.log('File upload procedure finished.');
    // Notification logic is now inside the upload functions
    
  } catch (error) {
    logger.error('Upload failed:', error);
    showNotification('Failed to attach file: ' + error.message, 'error');
    throw error;
  }
}

/**
 * Upload file to Claude.ai
 */
async function uploadToClaude(file) {
  // Method 1: Try to find and click the file input
  const fileInput = document.querySelector('input[type="file"][multiple]') || 
                    document.querySelector('input[type="file"]');
  
  if (fileInput) {
    
    // Create DataTransfer with file
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    fileInput.files = dataTransfer.files;
    
    // Trigger change event
    fileInput.dispatchEvent(new Event('change', { bubbles: true }));
    
    await new Promise(resolve => setTimeout(resolve, 200));
    return true;
  }
  
  // Method 2: Try drag & drop on the chat input area
  const dropZone = findClaudeDropZone();
  if (dropZone) {
    logger.log('Using drag & drop for Claude');
    await simulateFileDrop(dropZone, file);
    return true;
  }
  
  throw new Error('Could not find upload mechanism for Claude');
}

/**
 * Upload file to Gemini/AI Studio
 */
async function uploadToGemini(file) {
  // --- Strategy 1: Gemini (gemini.google.com) via Paste ---
  const geminiInputArea = document.querySelector('div[contenteditable="true"]');
  if (geminiInputArea) {
    logger.log('Detected Gemini UI. Attempting to paste file...');
    const success = await simulateFilePaste(geminiInputArea, file);
    if (success) {
      showNotification('File attached', 'success');
    } else {
      throw new Error('File attachment could not be verified in Gemini. The UI may have changed.');
    }
    return; // Stop here if Gemini UI is found
  }

  // --- Strategy 2: AI Studio (aistudio.google.com) via Drag & Drop ---
  const aiStudioDropZone = document.querySelector('[msfiledragdrop], ms-prompt-input-wrapper, .attachment-wrapper');
  if (aiStudioDropZone) {
    logger.log('Detected AI Studio UI. Attempting to drop file...');
    const success = await simulateFileDrop(aiStudioDropZone, file);
    if (success) {
      showNotification('File attached', 'success');
    } else {
      throw new Error('File attachment could not be verified in AI Studio.');
    }
    return; // Stop here if AI Studio UI is found
  }
  
  // --- Fallback Error ---
  throw new Error('Could not find a compatible input area for Gemini or AI Studio.');
}

/**
 * Find drop zone for Claude.ai
 */
function findClaudeDropZone() {
  // Try to find the main chat container or textarea
  const selectors = [
    '[contenteditable="true"]', // Main input area
    '.ProseMirror', // Rich text editor
    'fieldset', // Input fieldset container
    '[data-testid="chat-input"]',
    'div[role="textbox"]'
  ];
  
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) {
      return element;
    }
  }
  
  return null;
}

/**
 * Find drop zone for Gemini/AI Studio
 */
function findGeminiDropZone() {
  // Method 1: Most specific Gemini drop zone container
  let dropZone = document.querySelector('div[file-drop-zone]');
  if (dropZone) {
    logger.log('Drop zone found (Method 1: Gemini file-drop-zone)');
    return dropZone;
  }
  
  // Method 2: Rich text editor (can also accept drops)
  dropZone = document.querySelector('.ql-editor[contenteditable="true"]');
  if (dropZone) {
    logger.log('Drop zone found (Method 2: Gemini ql-editor)');
    return dropZone;
  }

  // Method 3: Specific dropzone attribute
  dropZone = document.querySelector('div[xapfileselectordropzone]');
  if (dropZone) {
    logger.log('Drop zone found (Method 3: Gemini xapfileselectordropzone)');
    return dropZone;
  }
  
  // Method 4: AI Studio specific msfiledragdrop directive
  dropZone = document.querySelector('[msfiledragdrop]');
  if (dropZone) {
    logger.log('Drop zone found (AI Studio msfiledragdrop)');
    return dropZone;
  }
  
  // Method 5: AI Studio prompt input wrapper
  dropZone = document.querySelector('ms-prompt-input-wrapper');
  if (dropZone) {
    logger.log('Drop zone found (AI Studio ms-prompt-input-wrapper)');
    return dropZone;
  }
  
  // Method 6: AI Studio textarea with msfilecopypaste
  const textarea = document.querySelector('[msfilecopypaste]');
  if (textarea) {
    logger.log('Using textarea parent as drop zone (AI Studio)');
    return textarea.closest('.prompt-input-wrapper-container') || textarea.parentElement;
  }
  
  // Method 7: AI Studio attachment wrapper
  dropZone = document.querySelector('.attachment-wrapper');
  if (dropZone) {
    logger.log('Drop zone found (AI Studio attachment-wrapper)');
    return dropZone;
  }

  // Method 8: Gemini input area component as fallback
  dropZone = document.querySelector('input-area-v2');
  if (dropZone) {
    logger.log('Drop zone found (Gemini input-area-v2 fallback)');
    return dropZone;
  }
  
  logger.warn('No drop zone found for Gemini/AI Studio');
  return null;
}

/**
 * Simulates pasting a file into a target element.
 * @param {HTMLElement} target The contenteditable element to paste into.
 * @param {File} file The file to be pasted.
 * @returns {Promise<boolean>} True if the attachment is verified, false otherwise.
 */
async function simulateFilePaste(target, file) {
  logger.log('--- Starting simulateFilePaste ---');
  
  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(file);

  try {
    logger.log('Dispatching paste event...');
    target.dispatchEvent(new ClipboardEvent('paste', {
      bubbles: true,
      cancelable: true,
      clipboardData: dataTransfer
    }));
    logger.log('Paste event dispatched.');

    // --- VERIFICATION ---
    logger.log('Waiting 1500ms for UI to update after paste...');
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    logger.log('--- Starting Verification ---');
    // Updated selector list for modern Gemini UI, including potential Polish localization
    const fileChip = document.querySelector(
      '.attachment-list-item, file-chip, [aria-label*="Attachment:"], [aria-label*="załącznik"], mat-chip[aria-label*="File"], .upload-chip-container'
    );

    if (fileChip) {
        logger.log('VERIFIED: Found file chip element:', fileChip);
        // We consider finding any chip as a success, as filename might be truncated.
        logger.log('SUCCESS: A file chip element was found in the UI.');
        return true;
    } else {
        // Fallback check: Sometimes a file preview appears directly
        const filePreview = document.querySelector('div[class*="file-preview"]');
        if (filePreview) {
          logger.log('VERIFIED: Found file preview element as a fallback.');
          return true;
        }
        logger.log('FAILED: Did not find a file chip or preview element after paste.');
        return false;
    }

  } catch (e) {
    logger.error('An error occurred during paste event dispatch:', e);
    return false;
  }
}

/**
 * Simulates dropping a file onto a target element. (For AI Studio)
 * @param {HTMLElement} target The element to drop the file onto.
 * @param {File} file The file to be dropped.
 * @returns {Promise<boolean>} True if the attachment is verified, false otherwise.
 */
async function simulateFileDrop(target, file) {
  logger.log('--- Starting simulateFileDrop (AI Studio) ---');
  
  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(file);

  try {
    target.dispatchEvent(new DragEvent('dragenter', { bubbles: true, cancelable: true, dataTransfer }));
    await new Promise(resolve => setTimeout(resolve, 200));
    
    target.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer }));
    await new Promise(resolve => setTimeout(resolve, 200));
    
    target.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer }));
    logger.log('Drop dispatched.');

    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Verification for AI Studio
    const attachmentWrapper = document.querySelector('.attachment-wrapper');
    if (attachmentWrapper && !attachmentWrapper.classList.contains('empty')) {
      logger.log('SUCCESS: AI Studio attachment wrapper is not empty.');
      return true;
    } else {
      logger.log('FAILED: AI Studio attachment wrapper is empty or not found.');
      return false;
    }

  } catch (e) {
    logger.error('An error occurred during drag-drop event dispatch:', e);
    return false;
  }
}

/**
 * Show temporary notification
 */
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    background: ${type === 'success' ? '#10b981' : '#ef4444'};
    color: white;
    border-radius: 8px;
    font-family: 'Google Sans', system-ui, sans-serif;
    font-size: 14px;
    z-index: 999999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    animation: slideIn 0.3s ease-out;
  `;
  
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(400px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.transition = 'opacity 0.3s, transform 0.3s';
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(400px)';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

/**
 * Finds the best input field on the page and pastes text into it.
 * @param {string} textToPaste - The full prompt text.
 */
async function pasteIntoBestInput(textToPaste) {
  const selectors = [
    "div.ql-editor[contenteditable='true']",       // Gemini's rich text editor
    "div[role='textbox'][contenteditable='true']", // Another common Gemini pattern
    ".ProseMirror[contenteditable='true']",       // Claude's editor
    "div[contenteditable='true']",               // Generic fallback
    'textarea',
    'input[type="text"]'
  ];

  let inputElement = null;
  for (const selector of selectors) {
    inputElement = document.querySelector(selector);
    if (inputElement) {
      break;
    }
  }

  if (!inputElement) {
    throw new Error("Could not find a suitable input field on the page.");
  }

  // 1. Set the content
  inputElement.focus(); // Ensure the element is active first.

  if (inputElement.isContentEditable) {
    if (PLATFORM === 'CLAUDE') {
        // For Claude's ProseMirror, we must simulate a paste event with HTML content
        // to correctly render line breaks, as direct .innerHTML/.textContent is ignored.
        logger.log('Simulating HTML paste event for Claude.');
        
        // For Claude's ProseMirror, we must simulate a paste event with HTML content
        // to correctly render line breaks. Each line is wrapped in a <div> to treat it
        // as a separate paragraph block, mimicking how rich text is copied from other editors.
        logger.log('Simulating structured HTML paste event for Claude.');

        const lines = textToPaste.split('\n');
        // Wrap each line in a <div>. For empty lines, insert a <br> to preserve the space.
        // This ensures tags like <gluon_system> and section breaks are rendered correctly.
        const formattedHtml = lines.map(line => `<div>${line || '<br>'}</div>`).join('');

        const dataTransfer = new DataTransfer();
        dataTransfer.setData('text/html', formattedHtml);
        dataTransfer.setData('text/plain', textToPaste); // Also provide plain text fallback.

        const pasteEvent = new ClipboardEvent('paste', {
            clipboardData: dataTransfer,
            bubbles: true,
            cancelable: true,
        });

        inputElement.dispatchEvent(pasteEvent);
    } else if (PLATFORM === 'GEMINI') { // This is where Gemini logic goes
        logger.log('Applying Gemini-specific pasting logic with hidden tags and formatting.');
        
        const lines = textToPaste.split('\n');
        let inSystemBlock = false;

        const finalHtml = lines.map(line => {
            const trimmedLine = line.trim();
            
            if (trimmedLine === '<gluon_system>') {
                inSystemBlock = true;
                return `<div style="display: none;">${line}</div>`;
            }
            if (trimmedLine === '</gluon_system>') {
                const result = `<div style="display: none;">${line}</div>`;
                inSystemBlock = false;
                return result;
            }
            if (trimmedLine === '<gluon_user>' || trimmedLine === '</gluon_user>') {
                return `<div style="display: none;">${line}</div>`;
            }
            if (inSystemBlock) {
                return `<div style="display: none;">${line || '<br>'}</div>`;
            }
            return `<div>${line || '<br>'}</div>`;
        }).join('');
        
        // FINAL STRATEGY: Use the modern Clipboard API to write to the clipboard,
        // then execute the native 'paste' command. The background script is now responsible
        // for focusing the document before this code is called.
        try {
            logger.log('Using Clipboard API to write HTML and then executing "paste" command.');
            
            // Focus the specific input element one last time to be safe.
            inputElement.focus();
            
            // Create blobs for the Clipboard API
            const htmlBlob = new Blob([finalHtml], { type: 'text/html' });
            const textBlob = new Blob([textToPaste], { type: 'text/plain' });

            // Create a ClipboardItem with both HTML and plain text versions
            const clipboardItem = new ClipboardItem({
                'text/html': htmlBlob,
                'text/plain': textBlob
            });

            // Write the item to the system clipboard
            await navigator.clipboard.write([clipboardItem]);

            // Now, command the document to paste from the clipboard
            const success = document.execCommand('paste');
            if (!success) {
                throw new Error('document.execCommand("paste") was unsuccessful.');
            }
        } catch (error) {
            logger.error('Critical paste failure:', error);
            throw new Error('Failed to paste prompt. Use Ctrl + V in model input.');
        }
    }
  } else {
    // Fallback for simple textarea/input elements.
    inputElement.value = textToPaste;
    inputElement.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
  }

  // 3. Set the cursor position inside <gluon_user> tag
  await new Promise(resolve => setTimeout(resolve, 50)); // Small delay for DOM update

  const content = (inputElement.textContent || inputElement.value) || '';
  const userTagStart = content.indexOf('<gluon_user>');
  
  if (userTagStart !== -1) {
    const userTagEnd = content.indexOf('>', userTagStart) + 1;
    
    try {
      if (inputElement.isContentEditable) {
        const selection = window.getSelection();
        const range = document.createRange();
        let textNode = null;
        let charCount = 0;
        
        function findTextNode(element) {
            for (const node of element.childNodes) {
                if (node.nodeType === Node.TEXT_NODE) {
                    if (charCount + node.length >= userTagEnd) {
                        textNode = node;
                        return true;
                    }
                    charCount += node.length;
                } else {
                    if (findTextNode(node)) return true;
                }
            }
            return false;
        }

        if (findTextNode(inputElement)) {
            range.setStart(textNode, userTagEnd - charCount);
            range.collapse(true);
            selection.removeAllRanges();
            selection.addRange(range);
        }
      } else {
        // Fallback for textarea/input
        inputElement.selectionStart = inputElement.selectionEnd = userTagEnd;
      }
    } catch (error) {
      logger.warn('Failed to set cursor position:', error);
      // Graceful degradation - just focus the input
      inputElement.focus();
    }
  }
  logger.log('Prompt pasted and cursor positioned.');
}