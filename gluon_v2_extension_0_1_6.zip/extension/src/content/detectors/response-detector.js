// Content scripts DEV_MODE - set to false for production
if (typeof CONTENT_DEV_MODE === 'undefined') {
  var CONTENT_DEV_MODE = false; // Change to false to disable logs
}

// Shared logger for all Gluon content scripts
if (typeof logger === 'undefined') {
  var logger = {
    _log: (level, ...args) => {
      // Don't log anything if not in dev mode, except errors
      if (!CONTENT_DEV_MODE && level !== 'error') {
        return;
      }

      const prefix = '[Gluon Content]';
      switch (level) {
        case 'log':
        case 'success':
          console.log(prefix, ...args);
          break;
        case 'warn':
          console.warn(prefix, ...args);
          break;
        case 'error':
          console.error(prefix, ...args);
          break;
        default:
          console.log(prefix, ...args);
      }
    },
    log: function(...args) { this._log('log', ...args); },
    warn: function(...args) { this._log('warn', ...args); },
    error: function(...args) { this._log('error', ...args); },
    success: function(...args) { this._log('success', '✅', ...args); },
  };
}

logger.log('Response detector active.');

let observer;
let debounceTimeout;
const processedMessages = new WeakSet();
const overlayDataCache = new Map();

function startObserver() {
    const targetNode = document.body;
    const config = { childList: true, subtree: true };

    observer = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                clearTimeout(debounceTimeout);
                debounceTimeout = setTimeout(scanForNewMessages, 500);
                return;
            }
        }
    });

    observer.observe(targetNode, config);
    logger.log('MutationObserver started for AI responses.');
    scanForNewMessages(); // Initial scan
}

function scanForNewMessages() {
    const selectors = [
        // Gemini/AI Studio
        'ms-chat-turn.model .turn-content',
        'div[data-turn-role="Model"] .turn-content',

        // Claude.ai (specific to user-provided HTML)
        '.font-claude-response', 
        
        // Generic fallbacks
        '[data-is-assistant="true"]',
        '.font-claude-message',
        'div[class*="font-user-message"] + div',
        '.assistant-message',
        '.model-response-text',
        '[role="article"]',
        '.prose'
    ];
    
    document.querySelectorAll(selectors.join(', ')).forEach(messageNode => {
        if (processedMessages.has(messageNode) || messageNode.querySelector('.gluon-response-overlay')) {
            return;
        }

        // Prioritize extracting text from a code block
        let textToParse = '';
        
        // Strategy 1: Find a code block (pre > code) containing the marker
        const codeBlocks = messageNode.querySelectorAll('pre code');
        let foundInCodeBlock = false;
        
        // Strategy 1: Find a generic <pre><code> block
        for (const block of codeBlocks) {
            const blockText = getTextFromCodeblock(block); // Use new function
            if (blockText && blockText.includes('@gluon:response')) {
                textToParse = blockText;
                logger.log('Strategy 1: Extracted text from a <pre><code> block.');
                foundInCodeBlock = true;
                break;
            }
        }

        // Strategy 2: Fallback to Gemini/AI Studio specific <ms-code-block>
        if (!foundInCodeBlock) {
            const geminiBlocks = messageNode.querySelectorAll('ms-code-block');
            for (const geminiBlock of geminiBlocks) {
                // Find the actual code element *inside* the component
                const innerCode = geminiBlock.querySelector('pre code');
                if (innerCode) {
                    const blockText = getTextFromCodeblock(innerCode); // Use new function
                    if (blockText && blockText.includes('@gluon:response')) {
                        textToParse = blockText;
                        logger.log('Strategy 2: Extracted text from <ms-code-block> (inner <code>).');
                        foundInCodeBlock = true;
                        break;
                    }
                }
            }
        }
        
        // Strategy 3: Fallback to the entire message node's text
        if (!foundInCodeBlock) {
            logger.log('Strategy 3: Falling back to full message text.');
            textToParse = getTextFromComplexNode(messageNode);
        }

        if (textToParse && textToParse.includes('@gluon:response')) {
            let cleanedText = textToParse; // Start with the extracted text

            // ✅ Usuń znaczniki cytatów Gemini/AI Studio FIRST
            cleanedText = cleanedText.replace(/\[cite_start\]/g, '');
            
            // Jeśli znajdujemy <gluon_system>, weź tylko tekst PO nim
            const systemEnd = cleanedText.lastIndexOf('</gluon_system>');
            if (systemEnd !== -1) {
                cleanedText = cleanedText.substring(systemEnd + 15); // +15 to długość </gluon_system>
                logger.log('Removed system prompt from detection');
            }
            
            // Jeśli nadal zawiera marker, wyślij
            if (cleanedText.includes('@gluon:response')) {

                logger.log('--- GLUON DEBUG START ---');
                logger.log('RAW TEXT TO PARSE:', textToParse);
                logger.log('CLEANED TEXT SENT:', cleanedText);
                logger.log('--- GLUON DEBUG END ---');

                processedMessages.add(messageNode);
                logger.log('Detected potential Gluon response. Sending to sidebar for parsing.');
                
                const messageId = `gluon-msg-${Date.now()}-${Math.random()}`;
                messageNode.dataset.gluonMessageId = messageId;

                logger.log(`Tagged element for injection: <${messageNode.tagName.toLowerCase()} class="${messageNode.className}"> with ID: ${messageId}`);
                
                chrome.runtime.sendMessage({
                    action: 'gluon_response_detected',
                    payload: {
                        rawText: cleanedText, // Wyślij oczyszczony tekst
                        messageId: messageId
                    }
                });
            }
        }
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'render_gluon_overlay') {
        const { messageId, overlayHtml, overlayData } = request.payload;
        const messageNode = document.querySelector(`[data-gluon-message-id="${messageId}"]`);

        if (messageNode) {
            // Zapisz pełne dane w cache pod messageId
            if (overlayData) {
                overlayDataCache.set(messageId, overlayData);
                logger.log(`Cached overlay data for ${messageId}`, overlayData);
            }

            const existingOverlay = messageNode.querySelector('.gluon-response-overlay');
            if (existingOverlay) existingOverlay.remove();

            messageNode.insertAdjacentHTML('beforeend', overlayHtml);
            logger.log(`Overlay rendered for message ${messageId}`);
            // Przekaż ID do funkcji ustawiającej event listenery
            setupOverlayEventListeners(messageNode, messageId);
            sendResponse({success: true});
        } else {
            logger.error(`INJECTION FAILED: Could not find message node with ID: ${messageId}. The element likely disappeared from the DOM after being tagged. This is common in dynamic web apps.`);
            sendResponse({success: false, error: 'Message node not found'});
        }
    }
    return true;
});

function setupOverlayEventListeners(overlayParent, messageId) {
    const overlay = overlayParent.querySelector('.gluon-response-overlay');
    if (!overlay) return;

    // Toggle overlay expand/collapse when clicking header
    const header = overlay.querySelector('.gluon-overlay-header');
    if (header) {
        header.addEventListener('click', (event) => {
            // Don't toggle if clicking a button inside header
            if (event.target.closest('button')) return;

            overlay.classList.toggle('collapsed');
            overlay.classList.toggle('expanded');

            // Rotate toggle icon
            const toggleIcon = header.querySelector('.gluon-toggle-icon');
            if (toggleIcon) {
                toggleIcon.textContent = overlay.classList.contains('collapsed') ? '▼' : '▲';
            }
        });

        // Support keyboard navigation
        header.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                header.click();
            }
        });
    }

    // Użyj delegacji zdarzeń dla wszystkich przycisków wewnątrz nakładki
    overlay.addEventListener('click', (event) => {
        const button = event.target.closest('button');
        if (!button) return;

        // Obsługa kliknięć przycisku "Find"
        if (button.classList.contains('gluon-btn-find')) {
            const filePath = button.dataset.filepath;
            const searchText = button.dataset.searchtext;

            if (filePath && searchText) {
                logger.log('Sending "find_in_editor" command:', { filePath, searchText });
                chrome.runtime.sendMessage({
                    action: 'find_in_editor',
                    payload: {
                        filePath,
                        searchText,
                    }
                });

                const originalText = button.textContent;
                button.textContent = '✔ Sent!';
                button.disabled = true;
                setTimeout(() => {
                    if (button) {
                       button.textContent = originalText;
                       button.disabled = false;
                    }
                }, 2000);
            }
        }

        // Obsługa przycisku "Apply" dla przekazywania plików (wsteczna kompatybilność)
        if (button.classList.contains('gluon-btn-apply')) {
            const cachedData = overlayDataCache.get(messageId);
            if (!cachedData) {
                logger.error(`No cached data found for ${messageId}! Cannot apply selection.`);
                return;
            }
            
            logger.log('Found cached data:', cachedData);

            const payload = {
                files: cachedData.files || (cachedData.data ? cachedData.data.found : []) || [],
                responseType: cachedData.responseType,
                handoff: cachedData.handoff,
                prompt: cachedData.prompt,
            };
            
            logger.log('Final payload from CACHE:', payload);
            
            chrome.runtime.sendMessage({
                action: 'apply_gluon_selection',
                payload: payload
            });
            
            const originalText = button.textContent;
            button.textContent = '✔ Applied!';
            
            setTimeout(() => {
                if(button) {
                   button.textContent = originalText;
                }
            }, 2000);

            overlayDataCache.delete(messageId);
        }

        // Obsługa przycisku "Ignore"
        if (button.classList.contains('gluon-btn-ignore')) {
            overlay.remove();
            overlayDataCache.delete(messageId);
        }
    });

    // Obsługa kliknięć na kafelki plików (znajdowanie w drzewie)
    overlay.querySelectorAll('.gluon-file-tile, .gluon-file-tile-missing').forEach(tile => {
        tile.addEventListener('click', (event) => {
            const filePath = tile.dataset.filepath;
            const projectPath = tile.dataset.project;
            const isMissing = tile.classList.contains('gluon-file-tile-missing');

            if (filePath) {
                logger.log('File tile clicked, searching in tree:', { filePath, projectPath, isMissing });

                // Send message to sidebar to search for this file
                chrome.runtime.sendMessage({
                    action: 'search_file_in_tree',
                    payload: {
                        filePath,
                        projectPath,
                        isMissing
                    }
                });

                // Visual feedback
                const originalBg = tile.style.background;
                tile.style.background = 'rgba(139, 92, 246, 0.2)';
                setTimeout(() => {
                    tile.style.background = originalBg;
                }, 1000);
            }
        });
    });
}

/**
 * Extracts text content from a code block element (<pre><code> or inner <code>),
 * attempting to preserve line breaks even with complex DOM structures (like Gemini/AI Studio).
 * @param {HTMLElement} codeElement - The <code> element (or similar).
 * @returns {string} The reconstructed text content.
 */
function getTextFromCodeblock(codeElement) {
    if (!codeElement) return '';

    // UJEDNOLICENIE LOGIKI: Używamy tej samej, najbardziej niezawodnej implementacji
    // co w getTextFromComplexNode, aby zapewnić spójne i poprawne odtwarzanie tekstu.
    let lines = [];
    let currentLine = '';

    function traverse(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            currentLine += node.textContent;
        } else if (node.nodeType === Node.ELEMENT_NODE) {
            // Ignoruj znane elementy UI, które nie powinny być częścią tekstu
            if (node.closest('.gluon-response-overlay, .actions-container, .turn-footer, button, mat-expansion-panel-header')) {
                return;
            }

            const tagName = node.tagName.toLowerCase();
            const displayStyle = window.getComputedStyle(node).display;

            // Traktuj elementy blokowe lub <br> jako potencjalne przełamanie linii
            if (displayStyle === 'block' || tagName === 'br' || tagName === 'div' || tagName === 'p' || tagName === 'pre') {
                // Wrzuć poprzednią linię, jeśli miała zawartość
                if (currentLine.trim()) {
                    lines.push(currentLine.trim()); // Przytnij białe znaki z końców linii
                }
                currentLine = ''; // Zresetuj dla bloku/przełamania

                // Przejdź przez dzieci *wewnątrz* bloku
                for (const child of node.childNodes) {
                    traverse(child);
                }

                // Wrzuć zawartość zebraną wewnątrz bloku, jeśli jakaś jest
                if (currentLine.trim()) {
                    lines.push(currentLine.trim());
                }
                currentLine = ''; // Zresetuj ponownie po bloku
            } else {
                // Elementy liniowe, po prostu kontynuuj przechodzenie przez dzieci
                for (const child of node.childNodes) {
                    traverse(child);
                }
            }
        }
    }

    for (const child of codeElement.childNodes) {
        traverse(child);
    }

    // Dodaj pozostały tekst z ostatniej linii
    if (currentLine.trim()) {
        lines.push(currentLine.trim());
    }

    // Połącz linie pojedynczym znakiem nowej linii
    return lines.join('\n');
}


/**
 * Extracts text content from a complex message node, attempting to reconstruct
 * line breaks based on block-level elements. Used as a fallback.
 * @param {HTMLElement} messageNode - The main message container element.
 * @returns {string} The reconstructed text content.
 */
function getTextFromComplexNode(messageNode) {
    if (!messageNode) return '';

    let lines = [];
    let currentLine = '';

    function traverse(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            currentLine += node.textContent;
        } else if (node.nodeType === Node.ELEMENT_NODE) {
             // Ignore known UI elements that shouldn't be part of the text
            if (node.closest('.gluon-response-overlay, .actions-container, .turn-footer, button, mat-expansion-panel-header')) {
                return;
            }

            const tagName = node.tagName.toLowerCase();
             const displayStyle = window.getComputedStyle(node).display;

            // Treat block elements or <br> as potential line breaks
             if (displayStyle === 'block' || tagName === 'br' || tagName === 'div' || tagName === 'p' || tagName === 'pre') {
                 // Push previous line if it had content
                if (currentLine.trim()) {
                     lines.push(currentLine.trim()); // Trim whitespace from ends of lines
                }
                currentLine = ''; // Reset for the block/break

                // Traverse children *within* the block
                for (const child of node.childNodes) {
                    traverse(child);
                }

                // Push content gathered within the block if any
                if (currentLine.trim()) {
                    lines.push(currentLine.trim());
                }
                currentLine = ''; // Reset again after the block
            } else {
                 // Inline elements, just continue traversing children
                for (const child of node.childNodes) {
                    traverse(child);
                }
            }
        }
    }

    for (const child of messageNode.childNodes) {
        traverse(child);
    }

    // Add any remaining text on the last line
    if (currentLine.trim()) {
        lines.push(currentLine.trim());
    }

    // Join lines with a single newline character
    return lines.join('\n');
}

startObserver();