// Tylko inject sidebar button
const btn = document.createElement('button');
btn.textContent = 'Gluon POC';
btn.style.cssText = 'position:fixed;top:10px;right:10px;z-index:9999;';
btn.onclick = () => {
  const iframe = document.createElement('iframe');
  iframe.src = chrome.runtime.getURL('sidebar/sidebar.html');
  iframe.style.cssText = 'position:fixed;top:0;right:0;width:300px;height:100%;border:1px solid #ccc;z-index:9998;';
  document.body.appendChild(iframe);
};
document.body.appendChild(btn);