import { contextLogger } from '../../common/logger.js';

// ============================================================================
// Context Management Module
// Zarządza plikami kontekstowymi, historią i załącznikami
// ============================================================================

import {
  selectedProjects, allProjects, previousContextHistory, contextTilesExpanded,
  selectedNodes, selectedEnvironmentId, enabledPromptIds, pendingConfigRestore, lastAction,
  setPreviousContextHistory, setPendingConfigRestore, setSelectedProjects, setSelectedEnvironmentId,
  setEnabledPromptIds, setLastAction,
  showStatusMessage, showError, showLoading, escapeHTML, getTimeAgo, formatSize, saveSelectedProjects
} from './stateManagement.js';

import {
  triggerFileTreeLoadForSelected, renderMergedFileTree, updateSelectionInfo,
  constructMultiProjectPayload, getProjectMapping
} from './fileTreeManagement.js';

import {
  renderPrompts
} from './templatePromptManagement.js';

import {
  savePromptToHistory,
  PromptHistoryNavigator
} from './promptHistoryManagement.js';

// ============================================================================
// Quick Task History Navigator
// ============================================================================

let quickTaskNavigator = null;

/**
 * Inicjalizuje navigator historii dla Quick Task
 */
export async function initQuickTaskHistory() {
  const quickTaskInput = document.getElementById('quickTaskInput');
  if (quickTaskInput) {
    quickTaskNavigator = new PromptHistoryNavigator(quickTaskInput, 'quick_task');
    await quickTaskNavigator.init();
  }
}

/**
 * Obsługuje nawigację strzałkami w Quick Task
 */
export function handleQuickTaskHistoryKeydown(event) {
  if (quickTaskNavigator) {
    quickTaskNavigator.handleKeyDown(event);
  }
}

// ============================================================================
// Context History
// ============================================================================

/**
 * Ładuje historię plików kontekstowych
 */
export function loadContextHistory() {
  chrome.runtime.sendMessage({
    action: 'get_context_files_history',
    payload: {
      selectedProjects: Array.from(selectedProjects)
    }
  });
}

/**
 * Renderuje listę historii kontekstu
 */
export function renderContextHistoryList(historyItems) {
  const container = document.getElementById('contextTiles');
  const showMoreBtn = document.getElementById('showMoreContextBtn');

  if (!historyItems || historyItems.length === 0) {
    container.innerHTML = '<div class="empty-state"><div class="empty-icon">📋</div><div class="empty-text">No saved contexts yet</div></div>';
    setPreviousContextHistory([]);
    showMoreBtn.style.display = 'none';
    return;
  }

  if (areHistoryItemsEqual(previousContextHistory, historyItems)) {
    return;
  }

  const currentMap = new Map(historyItems.map(item => [item.filepath, item]));
  const previousMap = new Map(previousContextHistory.map(item => [item.filepath, item]));
  const existingTiles = new Map([...container.querySelectorAll('.context-tile')].map(tile => [tile.dataset.filepath, tile]));

  // Usuń nieistniejące kafelki
  for (const [filepath, tile] of existingTiles.entries()) {
    if (!currentMap.has(filepath)) {
      tile.remove();
      existingTiles.delete(filepath);
    }
  }

  // Dodaj, zaktualizuj i uporządkuj kafelki
  historyItems.forEach((item, index) => {
    const existingTile = existingTiles.get(item.filepath);
    const previousItem = previousMap.get(item.filepath);
    let currentTileElement = existingTile;

    if (existingTile) {
      if (!areItemsEqual(item, previousItem)) {
        const newTile = createContextTile(item);
        existingTile.replaceWith(newTile);
        currentTileElement = newTile;
        existingTiles.set(item.filepath, newTile);
      }
    } else {
      const newTile = createContextTile(item);
      currentTileElement = newTile;
      existingTiles.set(item.filepath, newTile);
    }

    const expectedNode = container.children[index];
    if (expectedNode !== currentTileElement) {
      container.insertBefore(currentTileElement, expectedNode || null);
    }
  });

  // Zarządzaj przyciskiem "Show More"
  const totalCount = historyItems.length;
  const favoritedCount = historyItems.filter(item => item.favorite).length;

  container.classList.toggle('has-favorites', favoritedCount > 0);

  const visibleInCollapsed = favoritedCount > 0 ? favoritedCount : (totalCount > 0 ? 1 : 0);

  if (totalCount > visibleInCollapsed) {
    showMoreBtn.style.display = 'flex';
    const hiddenCount = totalCount - visibleInCollapsed;
    const btnText = showMoreBtn.querySelector('.btn-text');

    if (contextTilesExpanded) {
      container.classList.remove('collapsed');
      btnText.innerHTML = 'Show less';
      showMoreBtn.classList.add('expanded');
    } else {
      container.classList.add('collapsed');
      btnText.innerHTML = `Show <span id="hiddenCount">${hiddenCount}</span> more`;
      showMoreBtn.classList.remove('expanded');
    }
  } else {
    showMoreBtn.style.display = 'none';
    container.classList.remove('collapsed');
  }

  setPreviousContextHistory(historyItems);
}

/**
 * Porównuje dwie listy historii kontekstu
 */
function areHistoryItemsEqual(prev, current) {
  if (prev.length !== current.length) return false;

  for (let i = 0; i < prev.length; i++) {
    if (!areItemsEqual(prev[i], current[i])) {
      return false;
    }
  }

  return true;
}

/**
 * Porównuje dwa pojedyncze elementy historii
 */
function areItemsEqual(a, b) {
  return a.filepath === b.filepath &&
    a.filename === b.filename &&
    a.timestamp === b.timestamp &&
    a.size === b.size &&
    a.favorite === b.favorite &&
    JSON.stringify(a.config) === JSON.stringify(b.config);
}

/**
 * Tworzy element DOM kafelka kontekstowego
 */
function createContextTile(item) {
  const tile = document.createElement('div');
  tile.className = 'context-tile';
  tile.dataset.filepath = item.filepath;
  if (item.favorite) {
    tile.classList.add('favorited');
  }

  const date = new Date(item.timestamp);
  const timeAgo = getTimeAgo(date);
  const dateStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();

  const projectCount = item.config.projects.length;
  const fileCount = Object.values(item.config.selectedFiles).reduce((sum, files) => sum + files.length, 0);
  const promptCount = item.config.promptIds.length;
  const quickTask = item.config.quickTask || 'No task';

  const filenameParts = item.filename.match(/^(.+?)(\.[\w]+)$/);
  const namePrefix = filenameParts ? filenameParts[1] : item.filename;
  const extension = filenameParts && filenameParts[2] !== '.txt' ? filenameParts[2] : '';

  tile.innerHTML = `
    <div class="tile-restore-area">
      <button class="tile-favorite-btn ${item.favorite ? 'active' : ''}" title="${item.favorite ? 'Remove from favorites' : 'Add to favorites'}">
        ★
      </button>
      <div class="tile-icon">📄</div>
      <div class="tile-info">
        <div class="tile-name-container">
          <span class="tile-name-editable" title="${item.filepath}" data-extension="${extension}">${escapeHTML(namePrefix)}</span>
          <span class="tile-name-extension">${extension}</span>
        </div>
        <div class="tile-timestamp">${timeAgo} • ${dateStr}</div>
        <div class="tile-meta">${formatSize(item.size)} • ${fileCount} files • ${projectCount} projects</div>
        <div class="tile-prompts">${promptCount} prompts • ${escapeHTML(quickTask)}</div>
      </div>
      <button class="tile-attach-btn" title="Attach this file to AI">
        🔎 Attach
      </button>
    </div>
  `;

  if (item.warning) {
    const warningBadge = document.createElement('div');
    warningBadge.className = 'tile-warning';
    warningBadge.title = item.warning;
    warningBadge.textContent = '!';
    tile.appendChild(warningBadge);
  }

  const restoreArea = tile.querySelector('.tile-restore-area');
  restoreArea.addEventListener('click', (e) => {
    if (e.target.classList.contains('tile-attach-btn') ||
      e.target.classList.contains('tile-favorite-btn') ||
      e.target.classList.contains('tile-name-editable')) {
      return;
    }
    restoreConfig(item.config);
  });

  const favoriteBtn = tile.querySelector('.tile-favorite-btn');
  favoriteBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleFavorite(item.filepath, !item.favorite);
  });

  const attachBtn = tile.querySelector('.tile-attach-btn');
  attachBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    attachContextFile(item.filepath, item.filename);
  });

  const nameEditable = tile.querySelector('.tile-name-editable');
  nameEditable.addEventListener('click', (e) => {
    e.stopPropagation();
    startEditingTileName(nameEditable, item.filepath, item.filename);
  });

  return tile;
}

/**
 * Przełącza status ulubionego
 */
function toggleFavorite(filepath, isFavorite) {
  contextLogger.log('Toggling favorite for:', filepath, '→', isFavorite);

  const tile = document.querySelector(`.context-tile[data-filepath="${CSS.escape(filepath)}"]`);
  if (tile) {
    const favoriteBtn = tile.querySelector('.tile-favorite-btn');
    if (isFavorite) {
      tile.classList.add('favorited');
      favoriteBtn.classList.add('active');
      favoriteBtn.title = 'Remove from favorites';
    } else {
      tile.classList.remove('favorited');
      favoriteBtn.classList.remove('active');
      favoriteBtn.title = 'Add to favorites';
    }
  }

  chrome.runtime.sendMessage({
    action: 'toggle_context_favorite',
    payload: {
      filepath: filepath,
      favorite: isFavorite
    }
  });

  setTimeout(() => {
    loadContextHistory();
  }, 300);
}

/**
 * Rozpoczyna edycję nazwy kafelka
 */
function startEditingTileName(element, filepath, currentFilename) {
  const extension = element.dataset.extension || '';
  const currentPrefix = element.textContent.trim();

  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'tile-name-input';
  input.value = currentPrefix;
  input.maxLength = 100;

  element.style.display = 'none';
  element.parentNode.insertBefore(input, element);

  input.focus();
  input.select();

  const saveChanges = () => {
    const newPrefix = input.value.trim();

    if (!newPrefix) {
      input.remove();
      element.style.display = '';
      showStatusMessage('Name cannot be empty', 'error');
      return;
    }

    if (newPrefix === currentPrefix) {
      input.remove();
      element.style.display = '';
      return;
    }

    const newFilename = newPrefix + '.txt';

    if (!/^[a-zA-Z0-9_\-\s]+$/.test(newPrefix)) {
      showStatusMessage('Name can only contain letters, numbers, spaces, - and _', 'error');
      return;
    }

    contextLogger.log('Renaming context file:', currentFilename, '→', newFilename);

    element.textContent = newPrefix;
    input.remove();
    element.style.display = '';

    chrome.runtime.sendMessage({
      action: 'rename_context_file',
      payload: {
        filepath: filepath,
        newName: newFilename
      }
    });

    setTimeout(() => {
      loadContextHistory();

      setTimeout(() => {
        const updatedItem = previousContextHistory.find(item => item.filename === newFilename);
        if (updatedItem) {
          showStatusMessage('✅ File renamed!', 'success');
        } else {
          element.textContent = currentPrefix;
          showStatusMessage('❌ Failed to rename file', 'error');
        }
      }, 400);
    }, 300);
  };

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveChanges();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      input.remove();
      element.style.display = '';
    }
  });

  input.addEventListener('blur', () => {
    setTimeout(() => {
      if (document.contains(input)) {
        saveChanges();
      }
    }, 100);
  });
}

/**
 * Przywraca konfigurację z zapisanego kontekstu
 */
async function restoreConfig(savedConfig) {
  contextLogger.log('Restoring config:', savedConfig);

  try {
    setSelectedProjects(new Set(savedConfig.projects));
    await saveSelectedProjects();

    document.querySelectorAll('.project-tab-card').forEach(card => {
      const path = card.dataset.path;
      if (selectedProjects.has(path)) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    });

    setPendingConfigRestore(savedConfig);

    setSelectedEnvironmentId(savedConfig.environmentId);
    document.getElementById('environmentSelect').value = savedConfig.environmentId;
    await chrome.storage.local.set({ selectedEnvironmentId: savedConfig.environmentId });

    setEnabledPromptIds(new Set(savedConfig.promptIds));
    await chrome.storage.local.set({ enabledPromptIds: Array.from(enabledPromptIds) });

    const quickTaskInput = document.getElementById('quickTaskInput');
    if (quickTaskInput) {
      quickTaskInput.value = savedConfig.quickTask || '';
    }

    const logsInput = document.getElementById('logsInput');
    if (logsInput && savedConfig.logs) {
      logsInput.value = savedConfig.logs;
    }

    const includeLogsCheckbox = document.getElementById('includeLogs');
    if (includeLogsCheckbox) {
      includeLogsCheckbox.checked = savedConfig.includeLogs || false;
    }

    await triggerFileTreeLoadForSelected();

    renderPrompts();

    showStatusMessage('✅ Configuration restored!', 'success');

  } catch (error) {
    contextLogger.error('Failed to restore config:', error);
    showStatusMessage('❌ Failed to restore configuration', 'error');
  }
}

/**
 * Załącza plik kontekstowy
 */
export async function attachContextFile(filepath, filename) {
  showStatusMessage(`📎 Loading ${filename}...`, 'info');

  chrome.runtime.sendMessage({
    action: 'get_context_file_content',
    payload: {
      filepath: filepath,
      filename: filename
    }
  });
}

/**
 * Obsługuje przycisk "Show More"
 */
export function handleShowMoreContext() {
  const container = document.getElementById('contextTiles');
  const btn = document.getElementById('showMoreContextBtn');
  const btnText = btn.querySelector('.btn-text');
  if (container.classList.contains('collapsed')) {
    container.classList.remove('collapsed');
    btn.classList.add('expanded');
    btnText.innerHTML = 'Show less';
  } else {
    container.classList.add('collapsed');
    btn.classList.remove('expanded');

    const totalCount = previousContextHistory.length;
    const favoritedCount = previousContextHistory.filter(item => item.favorite).length;
    const visibleInCollapsed = favoritedCount > 0 ? favoritedCount : (totalCount > 0 ? 1 : 0);
    const hiddenCount = totalCount - visibleInCollapsed;

    btnText.innerHTML = `Show <span id="hiddenCount">${hiddenCount}</span> more`;
  }
}

/**
 * Parsuje załączone pliki z treści kontekstu
 */
export function parseAttachedFilesFromContext(content) {
  const attachedFiles = [];
  const lines = content.split('\n');
  let inAttachedSection = false;

  for (const line of lines) {
    const trimmedLine = line.trim();

    if (trimmedLine === '=== ATTACHED FILES ===') {
      inAttachedSection = true;
      continue;
    }

    if (trimmedLine.startsWith('===')) {
      if (inAttachedSection) break;
      continue;
    }

    if (inAttachedSection && trimmedLine.startsWith('- ')) {
      const contentPart = trimmedLine.substring(2);
      const parts = contentPart.split(':');
      if (parts.length >= 2) {
        const projectName = parts[0].trim();
        const relativePath = parts.slice(1).join(':').trim();
        attachedFiles.push({ projectName, relativePath });
      }
    }
  }

  return attachedFiles;
}

// ============================================================================
// Context File Generation
// ============================================================================

/**
 * Generuje plik kontekstowy
 */
export async function handleGenerateContextFile() {
  contextLogger.log('handleGenerateContextFile called');

  const projects = constructMultiProjectPayload();
  const quickTaskValue = document.getElementById('quickTaskInput').value.trim();
  const includeStructure = document.getElementById('includeStructure').checked;
  const includeLogs = document.getElementById('includeLogs').checked;
  const logsContent = document.getElementById('logsInput').value;

  if (projects.length === 0 && !(includeStructure && selectedProjects.size > 0)) {
    showStatusMessage('Select files OR enable structure export with selected projects.', 'error');
    return;
  }

  if (!selectedEnvironmentId) {
    showStatusMessage('Please select an environment first.', 'error');
    return;
  }

  contextLogger.log('Validation passed');
  showLoading('Generating...', 'generateBtn');

  let finalProjects = projects;
  if (includeStructure && projects.length === 0 && selectedProjects.size > 0) {
    contextLogger.log('Creating payload for structure-only export');
    finalProjects = Array.from(selectedProjects).map(projectPath => ({
      rootPath: projectPath,
      relativePaths: []
    }));
  }

  const payload = {
    projects: finalProjects,
    includeStructure,
    includeLogs,
    logs: (includeLogs && logsContent) ? logsContent : null,
    environmentId: selectedEnvironmentId,
    enabledPromptIds: Array.from(enabledPromptIds),
    quickTask: quickTaskValue ? quickTaskValue : null,
    projectMapping: getProjectMapping()
  };

  contextLogger.log('Payload details:');
  contextLogger.log('  - Projects count:', payload.projects.length);
  contextLogger.log('  - Include structure:', payload.includeStructure);
  contextLogger.log('  - Selected projects:', Array.from(selectedProjects));
  payload.projects.forEach((p, i) => {
    contextLogger.log(`  - Project ${i + 1}:`, p.rootPath, `(${p.relativePaths.length} files)`);
  });

  // Zapisz quick task do historii jeśli nie jest pusty
  if (quickTaskValue) {
    await savePromptToHistory('quick_task', quickTaskValue);
  }

  chrome.runtime.sendMessage({
    action: 'generate_context_file',
    payload: payload
  });
}

/**
 * Generuje prosty plik - tylko zaznaczone pliki (bez promptów, struktury, logów)
 */
export async function handleGenerateSimpleFile() {
  contextLogger.log('handleGenerateSimpleFile called');

  const projects = constructMultiProjectPayload();

  if (projects.length === 0) {
    showStatusMessage('Please select at least one file.', 'error');
    return;
  }

  // Nie wymagamy environment dla prostego generowania
  // Użyjemy pustego stringa jako fallback
  const environmentId = selectedEnvironmentId || '';

  contextLogger.log('Validation passed for simple file generation');
  showLoading('Generating...', 'generateSimpleBtn');

  const payload = {
    projects: projects,
    includeStructure: false,
    includeLogs: false,
    logs: null,
    environmentId: environmentId,
    enabledPromptIds: [],
    quickTask: null,
    projectMapping: getProjectMapping()
  };

  contextLogger.log('Simple file payload details:');
  contextLogger.log('  - Projects count:', payload.projects.length);
  payload.projects.forEach((p, i) => {
    contextLogger.log(`  - Project ${i + 1}:`, p.rootPath, `(${p.relativePaths.length} files)`);
  });

  chrome.runtime.sendMessage({
    action: 'generate_context_file',
    payload: payload
  });
}

/**
 * Obsługuje odpowiedź kopiowania plików
 */
export async function handleFileCopyResponse(projectsWithFiles) {
  if (!Array.isArray(projectsWithFiles) || projectsWithFiles.length === 0) {
    return showError("Failed to receive file content.");
  }

  if (lastAction === 'attach') {
    const project = projectsWithFiles[0];
    const file = project?.files[0];

    if (file && file.content != null) {
      const filename = file.path.split(/[\\/]/).pop() || file.path;
      chrome.runtime.sendMessage({
        action: 'inject_file_to_gemini',
        payload: {
          filename: filename,
          content: file.content,
          type: 'text/plain'
        }
      });
      showStatusMessage(`Attached ${filename}`, 'success');
    } else {
      showError(`Could not read file: ${file?.error || 'Unknown error'}`);
    }

  } else {
    let totalFiles = 0, totalSize = 0;
    const output = [];
    projectsWithFiles.forEach(p => p.files.forEach(f => {
      if (f.content) { totalFiles++; totalSize += new Blob([f.content]).size; }
    }));
    const generated = new Date().toLocaleString();
    output.push(`=== GLUON CONTEXT PACKAGE ===\nGenerated: ${generated}\nProjects: ${projectsWithFiles.length}\nTotal files: ${totalFiles}\nTotal size: ${formatSize(totalSize)}\n`);
    for (const project of projectsWithFiles) {
      const projectName = project.projectPath.split(/[\\/]/).pop() || project.projectPath;
      output.push(`\n=== PROJECT: ${projectName} ===\nPath: ${project.projectPath}\n`);
      for (const file of project.files) {
        if (file.error) output.push(`// ERROR reading file: ${file.path}\n// ${file.error}\n`);
        else if (file.content != null) output.push(`// ${file.path}\n${file.content}\n`);
      }
    }
    output.push('=== END CONTEXT ===');
    try {
      await navigator.clipboard.writeText(output.join('\n'));
      showStatusMessage(`Copied ${totalFiles} files (${formatSize(totalSize)})`, 'success');
    } catch (err) {
      showError('Could not copy to clipboard.');
    }
  }

  setLastAction(null);
}

/**
 * Kopiuje pliki
 */
export function handleCopyFiles() {
  const projects = constructMultiProjectPayload();
  if (projects.length === 0) return;
  showLoading('Copying...', 'copyBtn');
  setLastAction('copy');
  chrome.runtime.sendMessage({ action: 'get_files_multi', payload: { projects } });
}
