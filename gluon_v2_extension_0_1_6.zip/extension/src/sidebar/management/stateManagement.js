import { sidebarLogger } from '../../common/logger.js';

// ============================================================================
// State Management Module
// Zarządza stanem globalnym, storage i konfiguracją
// ============================================================================

// ============================================================================
// Global State Variables
// ============================================================================

export let fileTreeData = [];
export let selectedNodes = new Map();
export let selectedProjects = new Set();
export let allProjects = [];
export let searchQuery = '';
export let searchTimeout;
export let currentFileTreeRequestId = null;
export const tileContentCache = new Map();
export let lastAction = null;
export let environments = [];
export let selectedEnvironmentId = null;
export let enabledPromptIds = new Set();
export let pendingConfigRestore = null;
export let previousContextHistory = [];
export let templates = {};
export let activeTemplates = {
  auto_select: 'default',
  context_handoff: 'default',
  prompt_handoff: 'default'
};
export let contextTilesExpanded = false;
export let collapsedNodes = new Set();
export let licenseStatus = 'MISSING';
export let fileTreePollingInterval = null;

// ============================================================================
// Constants
// ============================================================================

export const POLLING_INTERVAL_MS = 1000;
export const BINARY_EXTENSIONS = new Set([
  'pdf', 'docx', 'doc', 'xlsx', 'xls', 'pptx', 'ppt', 'odt', 'ods',
  'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'tiff'
]);
export const PROJECT_COLORS = ['#00d4ff', '#00ff88', '#6366f1', '#f59e0b', '#ef4444', '#8b5cf6', '#10b981', '#f97316'];

// ============================================================================
// State Setters (for updating state from other modules)
// ============================================================================

export function setFileTreeData(data) { fileTreeData = data; }
export function setSelectedNodes(nodes) { selectedNodes = nodes; }
export function setSelectedProjects(projects) { selectedProjects = projects; }
export function setAllProjects(projects) { allProjects = projects; }
export function setSearchQuery(query) { searchQuery = query; }
export function setSearchTimeout(timeout) { searchTimeout = timeout; }
export function setCurrentFileTreeRequestId(id) { currentFileTreeRequestId = id; }
export function setLastAction(action) { lastAction = action; }
export function setEnvironments(envs) { environments = envs; }
export function setSelectedEnvironmentId(id) { selectedEnvironmentId = id; }
export function setEnabledPromptIds(ids) { enabledPromptIds = ids; }
export function setPendingConfigRestore(config) { pendingConfigRestore = config; }
export function setPreviousContextHistory(history) { previousContextHistory = history; }
export function setTemplates(tmpl) { templates = tmpl; }
export function setActiveTemplates(active) { activeTemplates = active; }
export function setContextTilesExpanded(expanded) { contextTilesExpanded = expanded; }
export function setCollapsedNodes(nodes) { collapsedNodes = nodes; }
export function setLicenseStatus(status) { licenseStatus = status; }
export function setFileTreePollingInterval(interval) { fileTreePollingInterval = interval; }

// ============================================================================
// Storage Functions
// ============================================================================

/**
 * Ładuje stan z chrome.storage.local
 */
export async function loadStateFromStorage() {
  const data = await chrome.storage.local.get({
    includeStructure: true,
    includeLogs: false,
    selectedEnvironmentId: null,
    enabledPromptIds: []
  });
  document.getElementById('includeStructure').checked = data.includeStructure;
  document.getElementById('includeLogs').checked = data.includeLogs;
  selectedEnvironmentId = data.selectedEnvironmentId;
  enabledPromptIds = new Set(data.enabledPromptIds);
}

/**
 * Zapisuje wybrane projekty do storage
 */
export async function saveSelectedProjects() {
  await chrome.storage.local.set({ selectedProjects: Array.from(selectedProjects) });
}

/**
 * Przywraca wybrane projekty ze storage
 */
export async function restoreSelectedProjects() {
  const { selectedProjects: storedProjects } = await chrome.storage.local.get('selectedProjects');
  if (storedProjects && Array.isArray(storedProjects)) {
    selectedProjects = new Set(storedProjects);
  }
}

/**
 * Obsługuje zmianę checkboxa struktury
 */
export function handleCheckboxChange(event) {
  sidebarLogger.log('handleCheckboxChange:'), {
    checked: event.target.checked,
    id: event.target.id
  };
  chrome.storage.local.set({ includeStructure: event.target.checked });
}

/**
 * Obsługuje zmianę checkboxa logów
 */
export function handleLogsCheckboxChange(event) {
  chrome.storage.local.set({ includeLogs: event.target.checked });
}

/**
 * Ładuje aktywne szablony
 */
export async function loadActiveTemplates() {
  const data = await chrome.storage.local.get({ active_templates: null });
  if (data.active_templates) {
    activeTemplates = data.active_templates;
  } else {
    await chrome.storage.local.set({ active_templates: activeTemplates });
  }
  sidebarLogger.log('Active templates loaded:', activeTemplates);
}

// ============================================================================
// UI Helper Functions
// ============================================================================

/**
 * Pokazuje loading na przycisku
 */
export function showLoading(message, buttonId) {
  const btn = document.getElementById(buttonId);
  if (btn) {
    btn.dataset.originalText = btn.textContent;
    btn.innerHTML = `<span class="spinner"></span> ${message}`;
    btn.disabled = true;
  } else {
    document.getElementById('fileTree').innerHTML = `<div class="empty-state"><div class="empty-icon">⏳</div><div class="empty-text">${message}</div></div>`;
  }
}

/**
 * Ukrywa loading z przycisku
 */
export function hideLoading(buttonId) {
  const btn = document.getElementById(buttonId);
  if (btn) {
    if (btn.dataset.originalText) {
      btn.textContent = btn.dataset.originalText;
      // Usuń spinner, jeśli istnieje
      const spinner = btn.querySelector('.spinner');
      if (spinner) {
        spinner.remove();
      }
    }
    // Ta linia jest kluczowa do ponownego włączenia przycisku
    btn.disabled = false;
  }
}

/**
 * Pokazuje komunikat o błędzie
 */
export function showError(message) {
  document.getElementById('fileTree').innerHTML = `<div class="empty-state is-error"><div class="empty-icon">⚠️</div><div class="empty-text"><strong>Error:</strong><span>${message}</span></div></div>`;
  showStatusMessage(message, 'error');
}

/**
 * Pokazuje status message (toast)
 */
export function showStatusMessage(message, type = 'info') {
  const statusEl = document.getElementById('statusMessage');
  statusEl.textContent = message;
  statusEl.className = `status-message ${type}`;
  statusEl.style.display = 'block';
  setTimeout(() => { statusEl.style.display = 'none'; }, type === 'error' ? 5000 : 3000);
}

/**
 * Formatuje rozmiar w bajtach
 */
export function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Escape HTML
 */
export function escapeHTML(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Formatuje czas jako "X ago"
 */
export function getTimeAgo(date) {
  const seconds = Math.floor((new Date() - date) / 1000);

  const intervals = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60
  };

  for (const [unit, secondsInUnit] of Object.entries(intervals)) {
    const interval = Math.floor(seconds / secondsInUnit);
    if (interval >= 1) {
      return `${interval} ${unit}${interval > 1 ? 's' : ''} ago`;
    }
  }

  return 'just now';
}

/**
 * Aktualizuje overlay blokujący
 */
export function updateBlockingOverlay() {
  const overlay = document.getElementById('blocking-overlay');
  const title = document.getElementById('overlay-title');
  const message = document.getElementById('overlay-message');
  const link = document.getElementById('overlay-link');

  const indicator = document.getElementById('connectionIndicator');
  const isConnected = indicator.classList.contains('connected');

  if (!isConnected) {
    title.textContent = 'Application Disconnected';
    message.textContent = 'Please launch the Gluon Desktop application to enable all features.';
    link.textContent = 'Download Gluon';
    overlay.style.display = 'flex';
    return;
  }

  if (licenseStatus !== 'VALID') {
    title.textContent = 'License Required';
    message.textContent = 'A valid license key is required for full functionality. Please enter your key in the Gluon Desktop settings.';
    link.textContent = 'Get a License';
    overlay.style.display = 'flex';
    return;
  }

  overlay.style.display = 'none';
}

/**
 * Aktualizuje status połączenia
 */
export function updateConnectionStatus(status) {
  const indicator = document.getElementById('connectionIndicator');
  if (status === 'Connected ✓' || status.includes('Connected')) {
    indicator.className = 'connection-indicator connected';
    indicator.title = 'Connected to Gluon Desktop';
  } else {
    indicator.className = 'connection-indicator disconnected';
    indicator.title = 'Disconnected - Click to reconnect';
    licenseStatus = 'MISSING';
    if (status === 'Disconnected') {
      showStatusMessage('Desktop app disconnected. Click indicator to reconnect.', 'error');
    }
  }
  updateBlockingOverlay();
}

/**
 * Stosuje motyw
 */
export function applyTheme(settings) {
  if (!settings || !settings.themeName) {
    sidebarLogger.warn('Brak ustawień motywu do zastosowania.');
    return;
  }

  const { themeName, theme80sColor1, theme80sColor2 } = settings;

  document.body.classList.remove('theme-80s');

  if (themeName === '80s') {
    document.body.classList.add('theme-80s');
    document.documentElement.style.setProperty('--theme-80s-bg', theme80sColor1);
    document.documentElement.style.setProperty('--theme-80s-accent', theme80sColor2);
  } else {
    document.documentElement.style.removeProperty('--theme-80s-bg');
    document.documentElement.style.removeProperty('--theme-80s-accent');
  }
}
