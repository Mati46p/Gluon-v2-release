import { fileTreeLogger } from '../../common/logger.js';

// ============================================================================
// File Tree Management Module
// Zarządza projektami, drzewem plików i selekcją
// ============================================================================

import {
  fileTreeData, selectedNodes, selectedProjects, allProjects, searchQuery, searchTimeout,
  currentFileTreeRequestId, lastAction, collapsedNodes, BINARY_EXTENSIONS, PROJECT_COLORS,
  POLLING_INTERVAL_MS, fileTreePollingInterval,
  setFileTreeData, setSelectedNodes, setSearchQuery, setSearchTimeout, setCurrentFileTreeRequestId,
  setLastAction, setFileTreePollingInterval,
  showLoading, hideLoading, showStatusMessage, showError, formatSize, escapeHTML,
  saveSelectedProjects
} from './stateManagement.js';

// ============================================================================
// Project Management
// ============================================================================

/**
 * Wypełnia listę projektów
 */
export async function populateProjects(projects) {
  const container = document.getElementById('projectSelect');
  container.innerHTML = '';

  const validPaths = new Set(projects.map(p => p.path));
  const invalidPaths = [...selectedProjects].filter(path => !validPaths.has(path));

  if (invalidPaths.length > 0) {
    fileTreeLogger.log('Cleaning up invalid projects from cache:', invalidPaths);
    invalidPaths.forEach(path => selectedProjects.delete(path));
    await saveSelectedProjects();
    invalidPaths.forEach(path => selectedNodes.delete(path));
    updateSelectionInfo();
  }

  if (projects && projects.length > 0) {
    projects.forEach(project => {
      const projectName = project.path.split(/[\\/]/).pop() || project.path;
      const card = document.createElement('div');
      card.className = 'project-tab-card';
      card.dataset.path = project.path;

      if (selectedProjects.has(project.path)) {
        card.classList.add('active');
      }

      card.innerHTML = `<span class="project-tab-name" title="${project.path}">${projectName}</span><div class="project-tab-indicator"></div>`;
      card.addEventListener('click', () => handleProjectTabClick(card, project.path));
      container.appendChild(card);
    });
  } else {
    container.innerHTML = '<div class="empty-text" style="padding: 10px;">No projects. Add via desktop.</div>';
  }
}

/**
 * Obsługuje kliknięcie na kartę projektu
 */
export async function handleProjectTabClick(cardElement, projectPath) {
  if (selectedProjects.has(projectPath)) {
    selectedProjects.delete(projectPath);
  } else {
    selectedProjects.add(projectPath);
  }
  cardElement.classList.toggle('active');
  await saveSelectedProjects();

  // Load environment based on project selection
  await loadEnvironmentForSelectedProjects();

  triggerFileTreeLoadForSelected();
}

/**
 * Ładuje środowisko dla wybranych projektów
 * Jeśli wybrany jest dokładnie 1 projekt, ładuje przypisane środowisko
 * W przeciwnym razie resetuje do domyślnego
 */
export async function loadEnvironmentForSelectedProjects() {
  if (selectedProjects.size === 1) {
    // Exactly one project selected - load its assigned environment
    const projectPath = Array.from(selectedProjects)[0];
    fileTreeLogger.log('Loading environment for project:', projectPath);
    chrome.runtime.sendMessage({
      action: 'get_environment_for_project',
      payload: { path: projectPath }
    });
  } else {
    // Zero or multiple projects - reset to default
    fileTreeLogger.log('Multiple or no projects selected, resetting to default');
    const { resetToDefaultEnvironment } = await import('./templatePromptManagement.js');
    await resetToDefaultEnvironment();
  }
}

/**
 * Odznacza wszystkie projekty
 */
export async function handleDeselectAllProjects() {
  stopFileTreePolling();
  selectedProjects.clear();
  await saveSelectedProjects();
  document.querySelectorAll('.project-tab-card.active').forEach(card => card.classList.remove('active'));
  clearFileTree();
  selectedNodes.clear();
  updateSelectionInfo();
}

/**
 * Ładuje drzewo plików dla wybranych projektów
 */
export async function triggerFileTreeLoadForSelected() {
  clearFileTree();
  selectedNodes.clear();
  updateSelectionInfo();

  const paths = Array.from(selectedProjects);
  if (paths.length > 0) {
    showLoading(`Loading ${paths.length} project(s)...`, 'generateBtn');
    const requestId = await chrome.runtime.sendMessage({
      action: 'get_file_trees',
      payload: { paths: paths }
    });
    setCurrentFileTreeRequestId(requestId);
    startFileTreePolling();
  }
}

// ============================================================================
// File Tree Rendering
// ============================================================================

/**
 * Renderuje scalone drzewo plików z wielu projektów
 */
export function renderMergedFileTree(projectsData) {
  const container = document.getElementById('fileTree');
  container.innerHTML = '';

  if (!Array.isArray(projectsData) || projectsData.length === 0) {
    return showEmptyState("Select a project to see files");
  }

  projectsData.forEach((projectData, index) => {
    if (projectData.error) {
      const errorSection = createErrorSection(projectData);
      container.appendChild(errorSection);
      return;
    }

    const projectName = projectData.projectPath.split(/[\\/]/).pop() || projectData.projectPath;
    const projectColor = PROJECT_COLORS[index % PROJECT_COLORS.length];

    const section = document.createElement('div');
    section.className = 'project-section';
    section.style.borderLeftColor = projectColor;

    if (collapsedNodes.has(projectData.projectPath)) {
      section.classList.add('collapsed');
    }

    const selectedCount = selectedNodes.get(projectData.projectPath)?.size || 0;
    const statsText = selectedCount > 0
      ? `${projectData.fileCount} files, ${selectedCount} sel.`
      : `${projectData.fileCount} files`;

    section.innerHTML = `
      <div class="project-header" title="${projectData.projectPath}">
        <span class="expand-icon">▼</span>
        <span class="project-name">${projectName}</span>
        <span class="project-stats" id="stats-${btoa(projectData.projectPath)}">${statsText}</span>
        <div class="project-actions">
          <button title="Select all files in this project">All</button>
          <button title="Clear selection in this project">None</button>
        </div>
      </div>
      <div class="project-tree-nodes"></div>`;

    section.querySelector('.project-header').addEventListener('click', () => {
      section.classList.toggle('collapsed');
      if (section.classList.contains('collapsed')) {
        collapsedNodes.add(projectData.projectPath);
      } else {
        collapsedNodes.delete(projectData.projectPath);
      }
    });
    section.querySelector('.project-actions button:first-child').onclick = (e) => {
      e.stopPropagation();
      handleSelectAllInProject(projectData.projectPath, projectData.tree);
    };
    section.querySelector('.project-actions button:last-child').onclick = (e) => {
      e.stopPropagation();
      handleClearAllInProject(projectData.projectPath);
    };

    container.appendChild(section);
    renderNodeTree(projectData.tree || [], section.querySelector('.project-tree-nodes'), 0, projectData.projectPath);
  });
}

/**
 * Tworzy sekcję błędu dla projektu
 */
function createErrorSection(projectData) {
  const projectName = projectData.projectPath.split(/[\\/]/).pop() || projectData.projectPath;
  const section = document.createElement('div');
  section.className = 'project-section error collapsed';
  section.innerHTML = `
    <div class="project-header" title="Error loading: ${projectData.projectPath}">
      <span class="expand-icon">▼</span>
      <span class="project-name">${projectName}</span>
      <span class="project-stats">Load Failed</span>
    </div>
    <div class="project-tree-nodes"><div class="error-message">${projectData.error}</div></div>`;
  section.querySelector('.project-header').addEventListener('click', () => section.classList.toggle('collapsed'));
  return section;
}

/**
 * Renderuje drzewo węzłów (rekurencyjnie)
 */
export function renderNodeTree(treeNodes, parentElement, depth, projectPath) {
  if (!parentElement) return;

  treeNodes.forEach(node => {
    const nodeElement = document.createElement('div');
    nodeElement.className = `tree-node ${node.nodeType}`;
    nodeElement.dataset.path = node.path;
    nodeElement.dataset.project = projectPath;

    const highlightedName = searchQuery && node.name.toLowerCase().includes(searchQuery)
      ? node.name.replace(new RegExp(`(${searchQuery})`, 'gi'), '<mark>$1</mark>')
      : node.name;

    const icon = node.nodeType === 'directory' ? '📁' : '📄';
    nodeElement.innerHTML = `<span class="tree-icon">${icon}</span><span class="tree-name">${highlightedName}</span>`;

    if (node.nodeType === 'file') {
      nodeElement.addEventListener('click', (event) => {
        event.stopPropagation();
        handleNodeClick(node, nodeElement, projectPath);
      });
      nodeElement.addEventListener('dblclick', (event) => {
        event.stopPropagation();
        handleFileDoubleClick(node, projectPath);
      });
      if (selectedNodes.get(projectPath)?.has(node.path)) {
        nodeElement.classList.add('selected');
      }
    } else if (node.nodeType === 'directory') {
      const uniqueId = `${projectPath}::${node.path}`;
      nodeElement.addEventListener('click', (event) => {
        event.stopPropagation();

        if (event.ctrlKey || event.metaKey) {
          if (collapsedNodes.has(uniqueId)) {
            collapsedNodes.delete(uniqueId);
          } else {
            collapsedNodes.add(uniqueId);
          }
          toggleFolderCollapse(nodeElement);
        } else {
          selectAllInFolder(node, projectPath);
        }
      });

      if (node.children && node.children.length > 0) {
        const filesInFolder = collectFilesFromFolder(node);
        const projectSelection = selectedNodes.get(projectPath);
        if (projectSelection) {
          const selectedCount = filesInFolder.filter(path => projectSelection.has(path)).length;
          if (selectedCount > 0) {
            nodeElement.classList.add('partially-selected');
            if (selectedCount === filesInFolder.length) {
              nodeElement.classList.add('fully-selected');
            }
          }
        }
      }
    }

    parentElement.appendChild(nodeElement);

    if (node.children && node.children.length > 0) {
      const childrenContainer = document.createElement('div');
      childrenContainer.className = 'tree-children';
      const uniqueId = `${projectPath}::${node.path}`;

      if (collapsedNodes.has(uniqueId)) {
        childrenContainer.style.display = 'none';
        nodeElement.classList.add('collapsed');
      }

      parentElement.appendChild(childrenContainer);
      renderNodeTree(node.children, childrenContainer, depth + 1, projectPath);
    }
  });
}

/**
 * Obsługuje kliknięcie na węzeł (plik)
 */
export function handleNodeClick(node, nodeElement, projectPath) {
  if (!selectedNodes.has(projectPath)) {
    selectedNodes.set(projectPath, new Set());
  }
  const projectSelection = selectedNodes.get(projectPath);
  if (projectSelection.has(node.path)) {
    projectSelection.delete(node.path);
  } else {
    projectSelection.add(node.path);
  }
  nodeElement.classList.toggle('selected');
  updateProjectStats(projectPath);
  updateSelectionInfo();
}

/**
 * Obsługuje podwójne kliknięcie na plik
 */
export function handleFileDoubleClick(node, projectPath) {
  const extension = node.name.split('.').pop().toLowerCase();

  if (BINARY_EXTENSIONS.has(extension)) {
    showStatusMessage(`Preparing ${node.name} for upload...`, 'info');
    const fullPath = `${projectPath.replace(/\\/g, '/')}/${node.path}`;
    fileTreeLogger.log(`Sending 'get_binary_file_for_upload' for path: ${fullPath}`);
    chrome.runtime.sendMessage({
      action: 'get_binary_file_for_upload',
      payload: { filepath: fullPath }
    });
  } else {
    showStatusMessage(`Attaching ${node.name}...`, 'info');
    setLastAction('attach');
    chrome.runtime.sendMessage({
      action: 'get_files_multi',
      payload: {
        projects: [{
          rootPath: projectPath,
          relativePaths: [node.path]
        }]
      }
    });
  }
}

/**
 * Zaznacza wszystkie pliki w projekcie
 */
export function handleSelectAllInProject(projectPath, tree) {
  const allFiles = (nodes, paths = []) => {
    for (const node of nodes) {
      if (node.nodeType === 'file') {
        paths.push(node.path);
      } else if (node.children) {
        allFiles(node.children, paths);
      }
    }
    return paths;
  };
  selectedNodes.set(projectPath, new Set(allFiles(tree)));
  const dataToRender = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
  renderMergedFileTree(dataToRender);
  updateProjectStats(projectPath);
  updateSelectionInfo();
}

/**
 * Czyści selekcję w projekcie
 */
export function handleClearAllInProject(projectPath) {
  if (selectedNodes.has(projectPath)) {
    selectedNodes.get(projectPath).clear();
  }
  const dataToRender = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
  renderMergedFileTree(dataToRender);
  updateProjectStats(projectPath);
  updateSelectionInfo();
}

/**
 * Aktualizuje statystyki projektu
 */
export function updateProjectStats(projectPath) {
  const statsEl = document.getElementById(`stats-${btoa(projectPath)}`);
  if (!statsEl) return;

  const projectData = fileTreeData.find(p => p.projectPath === projectPath);
  if (!projectData) return;

  const selectedCount = selectedNodes.get(projectPath)?.size || 0;
  statsEl.textContent = selectedCount > 0
    ? `${projectData.fileCount} files, ${selectedCount} sel.`
    : `${projectData.fileCount} files`;
}

/**
 * Zbiera wszystkie pliki z folderu (rekurencyjnie)
 */
export function collectFilesFromFolder(folderNode) {
  const filePaths = [];

  function traverse(node) {
    if (node.nodeType === 'file') {
      filePaths.push(node.path);
    } else if (node.nodeType === 'directory' && node.children) {
      node.children.forEach(child => traverse(child));
    }
  }

  if (folderNode.children) {
    folderNode.children.forEach(child => traverse(child));
  }

  return filePaths;
}

/**
 * Zaznacza/odznacza wszystkie pliki w folderze
 */
export function selectAllInFolder(folderNode, projectPath) {
  if (!selectedNodes.has(projectPath)) {
    selectedNodes.set(projectPath, new Set());
  }

  const projectSelection = selectedNodes.get(projectPath);
  const filesInFolder = collectFilesFromFolder(folderNode);

  const allSelected = filesInFolder.every(path => projectSelection.has(path));

  if (allSelected) {
    filesInFolder.forEach(path => projectSelection.delete(path));
  } else {
    filesInFolder.forEach(path => projectSelection.add(path));
  }

  const dataToRender = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
  renderMergedFileTree(dataToRender);
  updateProjectStats(projectPath);
  updateSelectionInfo();
}

/**
 * Przełącza collapse/expand dla folderu
 */
export function toggleFolderCollapse(nodeElement) {
  const childrenContainer = nodeElement.nextElementSibling;

  if (!childrenContainer || !childrenContainer.classList.contains('tree-children')) {
    return;
  }

  nodeElement.classList.toggle('collapsed');
  const isCollapsed = childrenContainer.style.display === 'none';

  if (isCollapsed) {
    childrenContainer.style.display = 'block';
    const icon = nodeElement.querySelector('.tree-icon');
    if (icon) icon.textContent = '📂';
  } else {
    childrenContainer.style.display = 'none';
    const icon = nodeElement.querySelector('.tree-icon');
    if (icon) icon.textContent = '📁';
  }
}

// ============================================================================
// Search & Filter
// ============================================================================

/**
 * Obsługuje wyszukiwanie
 */
export function handleSearch(event) {
  setSearchQuery(event.target.value.toLowerCase().trim());
  clearTimeout(searchTimeout);
  const timeout = setTimeout(() => {
    if (fileTreeData && fileTreeData.length > 0) {
      const filteredData = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
      renderMergedFileTree(filteredData);
    }
  }, 300);
  setSearchTimeout(timeout);
}

/**
 * Filtruje drzewo plików
 */
export function filterFileTree(projects) {
  return projects.reduce((acc, project) => {
    if (project.error) {
      acc.push(project);
      return acc;
    }
    const filterNodes = (nodes) => {
      return nodes.reduce((subAcc, node) => {
        const isMatch = node.name.toLowerCase().includes(searchQuery);
        if (node.nodeType === 'directory') {
          const filteredChildren = filterNodes(node.children || []);
          if (filteredChildren.length > 0 || isMatch) {
            subAcc.push({ ...node, children: filteredChildren });
          }
        } else if (isMatch) {
          subAcc.push(node);
        }
        return subAcc;
      }, []);
    };
    const filteredTree = filterNodes(project.tree);
    if (filteredTree.length > 0) {
      acc.push({ ...project, tree: filteredTree });
    }
    return acc;
  }, []);
}

// ============================================================================
// Selection Management
// ============================================================================

/**
 * Czyści selekcję
 */
export function handleClearSelection() {
  const projectsToUpdate = [...selectedNodes.keys()];
  selectedNodes.clear();
  document.querySelectorAll('.tree-node.selected').forEach(el => el.classList.remove('selected'));
  projectsToUpdate.forEach(updateProjectStats);
  updateSelectionInfo();
}

/**
 * Aktualizuje informacje o selekcji
 */
export function updateSelectionInfo() {
  const infoEl = document.getElementById('selectionInfo');
  const copyBtn = document.getElementById('copyBtn');
  const generateBtn = document.getElementById('generateBtn');
  const generateSimpleBtn = document.getElementById('generateSimpleBtn');

  let totalFiles = 0;
  let projectCount = 0;
  selectedNodes.forEach(filesSet => {
    if (filesSet.size > 0) {
      totalFiles += filesSet.size;
      projectCount++;
    }
  });

  if (totalFiles > 0) {
    infoEl.style.display = 'flex';
    document.getElementById('selectionCount').textContent = `${totalFiles} file${totalFiles > 1 ? 's' : ''} from ${projectCount} project${projectCount > 1 ? 's' : ''}`;

    const estimatedSize = 5 * totalFiles;
    document.getElementById('selectionSize').textContent = estimatedSize < 1024
      ? `~${estimatedSize} KB`
      : `~${(estimatedSize / 1024).toFixed(1)} MB`;

    copyBtn.disabled = false;
  } else {
    infoEl.style.display = 'none';
    copyBtn.disabled = true;
  }

  const hasSelectedFiles = totalFiles > 0;

  // Przycisk "Generate" jest teraz zawsze aktywny.
  // Walidacja jest przeprowadzana w momencie kliknięcia.
  if (generateBtn) {
    generateBtn.disabled = false;
  }

  // Przycisk "Simple" jest włączony tylko, gdy wybrano pliki.
  if (generateSimpleBtn) {
    generateSimpleBtn.disabled = !hasSelectedFiles;
  }
}

/**
 * Konstruuje payload dla wielu projektów
 */
export function constructMultiProjectPayload() {
  const projectsPayload = [];
  for (const [projectPath, filesSet] of selectedNodes.entries()) {
    if (filesSet.size > 0) projectsPayload.push({ rootPath: projectPath, relativePaths: Array.from(filesSet) });
  }
  return projectsPayload;
}

/**
 * Tworzy mapowanie projektów
 */
export function getProjectMapping() {
  const mapping = {};

  for (const projectPath of selectedProjects) {
    const projectName = projectPath.split(/[\\/]/).pop() || projectPath;
    const sanitizedName = projectName.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
    const key = `@gluon:${sanitizedName}`;
    mapping[key] = projectPath;
  }

  return mapping;
}

// ============================================================================
// File Tree Utilities
// ============================================================================

/**
 * Aktualizuje licznik plików
 */
export function updateFileCount() {
  const totalFiles = fileTreeData.reduce((sum, p) => sum + (p.fileCount || 0), 0);
  document.getElementById('fileCount').textContent = `${totalFiles} file${totalFiles !== 1 ? 's' : ''}`;
}

/**
 * Pokazuje empty state
 */
export function showEmptyState(message) {
  document.getElementById('fileTree').innerHTML = `<div class="empty-state"><div class="empty-icon">📁</div><div class="empty-text">${message}</div></div>`;
}

/**
 * Czyści drzewo plików
 */
export function clearFileTree() {
  showEmptyState('Select a project');
  setFileTreeData([]);
  updateFileCount();
}

/**
 * Znajduje i zaznacza plik w drzewie
 */
export function findAndSelectInTree(nodes, targetPath, selection) {
  for (const node of nodes) {
    if (node.path === targetPath && node.nodeType === 'file') {
      selection.add(node.path);
      return true;
    }
    if (node.children && node.children.length > 0) {
      if (findAndSelectInTree(node.children, targetPath, selection)) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Znajduje plik w drzewie (bez zaznaczania)
 */
export function findFileInTree(nodes, targetPath) {
  for (const node of nodes) {
    if (node.path === targetPath && node.nodeType === 'file') {
      return true;
    }
    if (node.children && node.children.length > 0) {
      if (findFileInTree(node.children, targetPath)) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Znajduje plik po nazwie (fallback)
 */
export function findAndSelectByFileName(nodes, fileName, selection) {
  for (const node of nodes) {
    if (node.nodeType === 'file' && node.name === fileName) {
      selection.add(node.path);
      return true;
    }
    if (node.children && node.children.length > 0) {
      if (findAndSelectByFileName(node.children, fileName, selection)) {
        return true;
      }
    }
  }
  return false;
}

// ============================================================================
// File Tree Polling
// ============================================================================

/**
 * Rozpoczyna polling drzewa plików
 */
export function startFileTreePolling() {
  stopFileTreePolling();
  const paths = Array.from(selectedProjects);
  if (paths.length > 0) {
    fileTreeLogger.log(`Starting file tree polling every ${POLLING_INTERVAL_MS}ms for:`, paths);
    const interval = setInterval(() => {
      chrome.runtime.sendMessage({
        action: 'get_file_trees',
        payload: { paths }
      });

      if (!window.pollCounter) window.pollCounter = 0;
      window.pollCounter++;
      if (window.pollCounter % 5 === 0) {
        // Co 5 iteracji (co 5 sekund) odśwież też historię kontekstu
        chrome.runtime.sendMessage({
          action: 'get_context_files_history',
          payload: { selectedProjects: Array.from(selectedProjects) }
        });
      }
    }, POLLING_INTERVAL_MS);
    setFileTreePollingInterval(interval);
  }
}

/**
 * Zatrzymuje polling drzewa plików
 */
export function stopFileTreePolling() {
  if (fileTreePollingInterval) {
    fileTreeLogger.log('Stopping file tree polling.');
    clearInterval(fileTreePollingInterval);
    setFileTreePollingInterval(null);
    window.pollCounter = 0;
  }
}

/**
 * Konfiguruje resizer dla drzewa plików
 */
export function setupFileTreeResizer() {
  const container = document.getElementById('fileTreeContainer');
  const resizer = document.getElementById('fileTreeResizer');

  if (!container || !resizer) return;

  let isResizing = false;
  let startY = 0;
  let startHeight = 0;

  chrome.storage.local.get({ fileTreeHeight: 400 }, (data) => {
    container.style.height = `${data.fileTreeHeight}px`;
  });

  resizer.addEventListener('mousedown', (e) => {
    isResizing = true;
    startY = e.clientY;
    startHeight = container.offsetHeight;

    resizer.classList.add('resizing');
    document.body.classList.add('resizing');

    e.preventDefault();
  });

  document.addEventListener('mousemove', (e) => {
    if (!isResizing) return;

    const delta = e.clientY - startY;
    const newHeight = Math.max(200, Math.min(800, startHeight + delta));

    container.style.height = `${newHeight}px`;

    e.preventDefault();
  });

  document.addEventListener('mouseup', () => {
    if (!isResizing) return;

    isResizing = false;
    resizer.classList.remove('resizing');
    document.body.classList.remove('resizing');

    const currentHeight = container.offsetHeight;
    chrome.storage.local.set({ fileTreeHeight: currentHeight });

    fileTreeLogger.log('File tree height saved:', currentHeight);
  });
}