import { parserLogger } from '../../common/logger.js';

// ============================================================================
// AI Integration & Command Parsing Module
// Parsuje komendy AI, obsługuje auto-selekcję i overlay'e
// ============================================================================

import {
  fileTreeData, selectedNodes, allProjects, searchQuery,
  showStatusMessage, escapeHTML
} from './stateManagement.js';

import {
  renderMergedFileTree, updateSelectionInfo, updateProjectStats,
  findAndSelectInTree, findFileInTree, findAndSelectByFileName,
  getProjectMapping, filterFileTree
} from './fileTreeManagement.js';

// ============================================================================
// Gluon Command Parsing
// ============================================================================

/**
 * Parsuje komendy Gluon z tekstu
 */
export function parseGluonCommands(text) {
  try {
    const jsonMatch = text.match(/\{[\s\S]*?"@gluon:select"[\s\S]*?\}/);
    if (!jsonMatch) return null;

    const parsed = JSON.parse(jsonMatch[0]);
    if (parsed["@gluon:select"] && Array.isArray(parsed["@gluon:select"])) {
      return {
        action: 'select_files',
        files: parsed["@gluon:select"]
      };
    }
  } catch (e) {
    parserLogger.error('Failed to parse Gluon command:', e);
  }
  return null;
}

/**
 * Obsługuje odpowiedź AI
 */
export function handleAIResponse(responseText) {
  const command = parseGluonCommands(responseText);
  if (command && command.action === 'select_files') {
    autoSelectFiles(command.files);
    showStatusMessage(`Auto-selected ${command.files.length} files`, 'success');
  }
}

/**
 * Automatycznie zaznacza pliki
 */
export function autoSelectFiles(filePaths) {
  fileTreeData.forEach(project => {
    if (!selectedNodes.has(project.projectPath)) {
      selectedNodes.set(project.projectPath, new Set());
    }
    const projectSelection = selectedNodes.get(project.projectPath);

    filePaths.forEach(requestedPath => {
      const normalizedPath = requestedPath.replace(/\\/g, '/');
      if (fileExistsInTree(project.tree, normalizedPath)) {
        projectSelection.add(normalizedPath);
      }
    });
  });

  const dataToRender = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
  renderMergedFileTree(dataToRender);
  updateSelectionInfo();
}

/**
 * Sprawdza czy plik istnieje w drzewie
 */
function fileExistsInTree(nodes, path) {
  for (const node of nodes) {
    if (node.path === path) return true;
    if (node.children && fileExistsInTree(node.children, path)) return true;
  }
  return false;
}

// ============================================================================
// Auto-Selection from AI Commands
// ============================================================================

/**
 * Obsługuje auto-selekcję
 */
export function handleAutoSelect(commandData, clearPrevious = true) {
  parserLogger.success('handleAutoSelect called!');
  parserLogger.log('Command data:', commandData);

  let projectFileMap = new Map();
  let isNewFormat = false;

  // NOWY FORMAT: {"@gluon:backend": [...], "@gluon:frontend": [...]}
  if (typeof commandData === 'object' && !Array.isArray(commandData)) {
    isNewFormat = true;

    for (const [key, files] of Object.entries(commandData)) {
      if (key.startsWith('@gluon:') && key !== '@gluon:select' && key !== '@gluon:response') {
        projectFileMap.set(key, files);
      }
    }

    parserLogger.log('New multi-project format detected:', projectFileMap);
  }
  // STARY FORMAT: ["file1.js", "file2.js"]
  else if (Array.isArray(commandData)) {
    parserLogger.log('Legacy format detected (array of files)');
    projectFileMap.set('legacy', commandData);
  }
  else {
    showStatusMessage('Invalid command format', 'error');
    return;
  }

  if (projectFileMap.size === 0) {
    showStatusMessage('No files specified in command', 'error');
    return;
  }

  if (clearPrevious) {
    parserLogger.log('Clearing previous selection...');
    selectedNodes.clear();
    document.querySelectorAll('.tree-node.selected').forEach(el => {
      el.classList.remove('selected');
    });
  }

  let selectedCount = 0;
  let notFoundFiles = [];
  let totalFiles = 0;

  if (isNewFormat) {
    const projectMapping = getProjectMapping();
    parserLogger.log('Project mapping:', projectMapping);

    for (const [gluonKey, files] of projectFileMap.entries()) {
      const projectPath = projectMapping[gluonKey];

      if (!projectPath) {
        parserLogger.warn(`Project key ${gluonKey} not found in current selection`);
        notFoundFiles.push(`${gluonKey} (not loaded)`);
        totalFiles += files.length;
        continue;
      }

      const projectData = fileTreeData.find(p => p.projectPath === projectPath);
      if (!projectData || projectData.error) {
        parserLogger.warn(`Project data not found for: ${projectPath}`);
        files.forEach(file => notFoundFiles.push(`${file} (project not loaded)`));
        totalFiles += files.length;
        continue;
      }

      if (!selectedNodes.has(projectPath)) {
        selectedNodes.set(projectPath, new Set());
      }
      const projectSelection = selectedNodes.get(projectPath);

      const normalizedPaths = files.map(p => p.replace(/\\/g, '/'));

      normalizedPaths.forEach(requestedPath => {
        totalFiles++;
        if (findAndSelectInTree(projectData.tree, requestedPath, projectSelection)) {
          selectedCount++;
        } else {
          const fileName = requestedPath.split('/').pop();
          if (findAndSelectByFileName(projectData.tree, fileName, projectSelection)) {
            selectedCount++;
          } else {
            notFoundFiles.push(`${requestedPath} (project ${gluonKey})`);
          }
        }
      });

      updateProjectStats(projectPath);
    }

  } else {
    // === STARY FORMAT: lista plików bez określenia projektu ===
    const filePaths = projectFileMap.get('legacy');
    totalFiles = filePaths.length;
    const normalizedPaths = filePaths.map(p => p.replace(/\\/g, '/'));

    fileTreeData.forEach(project => {
      if (project.error) return;

      if (!selectedNodes.has(project.projectPath)) {
        selectedNodes.set(project.projectPath, new Set());
      }
      const projectSelection = selectedNodes.get(project.projectPath);

      normalizedPaths.forEach(requestedPath => {
        if (findAndSelectInTree(project.tree, requestedPath, projectSelection)) {
          selectedCount++;
        } else {
          const fileName = requestedPath.split('/').pop();
          if (findAndSelectByFileName(project.tree, fileName, projectSelection)) {
            selectedCount++;
          }
        }
      });

      updateProjectStats(project.projectPath);
    });

    // Zbierz nieznalezione pliki
    normalizedPaths.forEach(path => {
      let found = false;
      fileTreeData.forEach(project => {
        if (project.tree && findFileInTree(project.tree, path)) {
          found = true;
        }
      });
      if (!found) {
        notFoundFiles.push(path);
      }
    });
  }

  // Odśwież UI
  if (selectedCount > 0) {
    const dataToRender = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
    renderMergedFileTree(dataToRender);
    updateSelectionInfo();

    const formatLabel = isNewFormat ? 'multi-project' : 'legacy';
    const statusMsg = clearPrevious
      ? `🤖 Selected ${selectedCount}/${totalFiles} files [${formatLabel}] (previous cleared)`
      : `🤖 Added ${selectedCount}/${totalFiles} files [${formatLabel}] to selection`;

    showStatusMessage(
      statusMsg,
      selectedCount === totalFiles ? 'success' : 'info'
    );

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'gluon_files_auto_selected',
          format: formatLabel,
          selectedCount: selectedCount,
          totalCount: totalFiles
        });
      }
    });
  }

  // Pokaż informację o nieznalezionych plikach
  if (notFoundFiles.length > 0) {
    parserLogger.warn('Files not found:', notFoundFiles);
    setTimeout(() => {
      showStatusMessage(
        `⚠️ ${notFoundFiles.length} file(s) not found in loaded projects`,
        'error'
      );
    }, 3500);
  }
}

// ============================================================================
// Response Parsing & Overlay
// ============================================================================

/**
 * Obsługuje wykrytą odpowiedź Gluon
 */
export function handleDetectedResponse({ rawText, messageId }) {
  const result = parseGluonResponse(rawText, fileTreeData, allProjects);
  parserLogger.log('Parse result:', result);

  let overlayHtml = '';
  let overlayData = null;

  parserLogger.log('Parser status:', result.status, 'Type:', result.type);

  switch (result.status) {
    case 'success':
      if (result.type === 'code_locations') {
        overlayHtml = createCodeLocationsOverlay(result.data);
      } else {
        overlayHtml = createSuccessOverlay(result.data);
      }
      overlayData = result.data;
      break;
    case 'partial':
      overlayHtml = createPartialOverlay(result.data);
      overlayData = result.data;
      break;
    case 'error':
      if (result.type !== 'format') {
        overlayHtml = createErrorOverlay(result);
        overlayData = result;
      }
      parserLogger.log('Error overlay generated:', !!overlayHtml, result.message);
      break;
  }

  if (overlayHtml) {
    chrome.runtime.sendMessage({
      action: 'render_gluon_overlay',
      payload: {
        messageId,
        overlayHtml,
        overlayData
      }
    });
  }
}

/**
 * Parsuje odpowiedź Gluon
 */
export function parseGluonResponse(rawText, fileTreeData, allProjects) {
  const jsonRegex = /```json\s*([\s\S]*?)\s*```|(\{\s*"@gluon:response"[\s\S]*\})/s;
  const match = rawText.match(jsonRegex);

  if (!match) {
    return { status: 'error', type: 'format', message: 'No valid JSON block with @gluon:response found.' };
  }

  const jsonString = match[1] || match[2];

  try {
    const sanitizedJsonString = jsonString
      .replace(/,\s*\]/g, ']')
      .replace(/,\s*\}/g, '}');

    const parsed = JSON.parse(sanitizedJsonString);
    const response = parsed['@gluon:response'];

    if (!response) {
      return { status: 'error', type: 'format', message: 'Missing "@gluon:response" field.' };
    }

    // Support both formats:
    // 1. String format from prompts: {"@gluon:response": "auto_select", ...}
    // 2. Object format for code locations: {"@gluon:response": {type: "code_locations", ...}}
    let responseType;
    let responseData;

    if (typeof response === 'string') {
      // New format from prompt-generator.js
      responseType = response; // "auto_select", "context_handoff", "prompt_handoff"
      responseData = parsed; // The full object contains other fields like @gluon:files, @gluon:handoff, etc.
    } else if (typeof response === 'object') {
      // Legacy format for code_locations
      responseType = response.type || 'file_handoff';
      responseData = response;
    } else {
      return { status: 'error', type: 'format', message: 'Invalid "@gluon:response" type. Expected string or object.' };
    }

    // --- Nowy parser "Code Locations" ---
    if (responseType === 'code_locations') {
      if (!Array.isArray(responseData.locations) || responseData.locations.length === 0) {
        return { status: 'error', type: 'validation', message: '"locations" array is missing or empty.' };
      }

      const validatedLocations = [];
      const errors = [];

      responseData.locations.forEach((loc, index) => {
        if (typeof loc.file !== 'string' || typeof loc.searchText !== 'string') {
          errors.push(`Location ${index} is missing "file" or "searchText".`);
          return;
        }

        let foundInProject = null;
        const normalizedPath = loc.file.replace(/\\/g, '/');

        for (const projectData of fileTreeData) {
          if (projectData.tree && findFileInTree(projectData.tree, normalizedPath)) {
            foundInProject = projectData;
            break;
          }
        }

        if (foundInProject) {
          validatedLocations.push({
            project: foundInProject.projectPath,
            file: normalizedPath,
            line: loc.line,
            function: loc.function,
            searchText: loc.searchText,
          });
        } else {
          errors.push(`File "${loc.file}" not found in any selected project.`);
        }
      });

      if (errors.length > 0) {
        return { status: 'error', type: 'validation', message: errors.join('; ') };
      }

      return {
        status: 'success',
        type: 'code_locations',
        data: {
          responseType: 'code_locations',
          locations: validatedLocations
        }
      };
    }

    // --- File Handoff Parser (handles both old and new formats) ---
    const foundFiles = [];
    const notFoundFiles = [];

    // New format uses @gluon:files with project mapping
    if (parsed['@gluon:files']) {
      const gluonFiles = parsed['@gluon:files'];

      // Build project mapping (same logic as response-parser.js)
      const projectMapping = new Map();
      const projectsToMap = allProjects && allProjects.length > 0
        ? allProjects
        : fileTreeData.map(p => ({ path: p.projectPath }));

      projectsToMap.forEach((project) => {
        const projectPath = project.path || project.projectPath;
        if (!projectPath) return;
        const projectName = projectPath.split(/[\\/]/).pop() || projectPath;
        const sanitizedName = projectName.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
        const gluonKey = `@gluon:${sanitizedName}`;

        projectMapping.set(gluonKey, projectPath);
        projectMapping.set(projectName, projectPath);
      });

      // Validate files from @gluon:files
      for (const [gluonKey, fileList] of Object.entries(gluonFiles)) {
        const projectPath = projectMapping.get(gluonKey);

        if (!projectPath) {
          fileList.forEach(file => notFoundFiles.push(file));
          continue;
        }

        const projectData = fileTreeData.find(p => p.projectPath === projectPath);
        if (!projectData) {
          fileList.forEach(file => notFoundFiles.push(file));
          continue;
        }

        fileList.forEach(filePath => {
          const normalizedPath = filePath.replace(/\\/g, '/');
          if (findFileInTree(projectData.tree || [], normalizedPath)) {
            foundFiles.push({ project: projectPath, path: normalizedPath });
          } else {
            notFoundFiles.push(normalizedPath);
          }
        });
      }
    }
    // Old format uses response.files array
    else {
      const files = responseData.files || (Array.isArray(responseData) ? responseData : []);
      if (!Array.isArray(files)) {
        return { status: 'error', type: 'format', message: 'Expected an array of files or @gluon:files object.' };
      }

      files.forEach(filePath => {
        let found = false;
        for (const project of allProjects) {
          const projectData = fileTreeData.find(p => p.projectPath === project.path);
          if (projectData && findFileInTree(projectData.tree || [], filePath)) {
            foundFiles.push({ project: project.path, path: filePath });
            found = true;
            break;
          }
        }
        if (!found) notFoundFiles.push(filePath);
      });
    }

    // Allow partial success even if no files are found
    // This enables handoff/reasoning to work even when file validation fails
    const data = {
      responseType: responseType,
      found: foundFiles,
      notFound: notFoundFiles,
      handoff: parsed['@gluon:handoff'] || responseData.handoff,
      prompt: responseData.prompt,
      reasoning: parsed['@gluon:reasoning'],
      summary: foundFiles.length > 0
        ? `${foundFiles.length} files found.`
        : 'No files found in loaded projects.',
      files: foundFiles,
    };

    // Return partial if some files weren't found, or if no files were found but we have handoff/reasoning
    if (foundFiles.length === 0 && notFoundFiles.length > 0) {
      return {
        status: 'partial',
        data: data,
        message: `No specified files were found in loaded projects. ${notFoundFiles.length} file(s) not found.`
      };
    }

    if (notFoundFiles.length > 0) {
      return { status: 'partial', data: data, message: `${notFoundFiles.length} files not found.` };
    }

    return { status: 'success', type: 'file_handoff', data };

  } catch (e) {
    return { status: 'error', type: 'format', message: `JSON parsing failed: ${e.message}` };
  }
}

/**
 * Tworzy overlay dla code locations
 */
function createCodeLocationsOverlay(data) {
  const locationsHtml = data.locations.map(loc => {
    const finalPath = `${loc.project}/${loc.file}`.replace(/\\/g, '/');

    return `
      <li class="gluon-overlay-item">
        <div class="gluon-overlay-item-info">
          <span class="gluon-overlay-item-main" title="${escapeHTML(loc.searchText)}">${escapeHTML(loc.searchText)}</span>
          <span class="gluon-overlay-item-sub" title="${escapeHTML(loc.file)}">${loc.line ? `:${loc.line}` : ''}</span>
        </div>
        <button class="gluon-btn-find"
                data-filepath="${escapeHTML(finalPath)}"
                data-searchtext="${escapeHTML(loc.searchText)}">
          Find
        </button>
      </li>
    `;
  }).join('');

  return `
    <div class="gluon-response-overlay">
      <div class="gluon-overlay-header">
        <span class="gluon-overlay-logo">⚡️</span>
        <span class="gluon-overlay-title">Code Inspector</span>
        <button class="gluon-btn-ignore" title="Close">&times;</button>
      </div>
      <ul class="gluon-overlay-list">${locationsHtml}</ul>
    </div>
  `;
}

/**
 * Tworzy overlay sukcesu
 */
function createSuccessOverlay(data) {
  const responseType = data.responseType || 'auto_select';
  const filesHtml = data.found.map(f => `
    <li class="gluon-file-tile" data-filepath="${escapeHTML(f.path)}" data-project="${escapeHTML(f.project)}" style="cursor: pointer;" title="Click to find in file tree">
      <span class="file-icon">📄</span>
      <span class="file-path">${escapeHTML(f.path)}</span>
    </li>
  `).join('');

  // Określ tytuł i dodatkową zawartość w zależności od typu
  let title = 'File Handoff';
  let additionalContent = '';
  let overlayClass = '';

  if (responseType === 'auto_select') {
    title = 'Auto Select';

    // Dodaj reasoning jeśli istnieje
    if (data.reasoning) {
      additionalContent = `
        <div class="overlay-reasoning">
          <strong>Reasoning:</strong>
          <p>${escapeHTML(data.reasoning)}</p>
        </div>
      `;
    }
  } else if (responseType === 'context_handoff') {
    title = 'Context Handoff';
    overlayClass = 'context-handoff';

    if (data.handoff) {
      const h = data.handoff;
      additionalContent = `
        <div class="handoff-sections">
          ${h.summary ? `
            <div class="handoff-section">
              <strong>Summary:</strong>
              <p>${escapeHTML(h.summary)}</p>
            </div>
          ` : ''}

          ${h.solved_problems && h.solved_problems.length > 0 ? `
            <div class="handoff-section">
              <strong>Solved Problems:</strong>
              <ul>
                ${h.solved_problems.map(p => `<li>${escapeHTML(p)}</li>`).join('')}
              </ul>
            </div>
          ` : ''}

          ${h.current_problem ? `
            <div class="handoff-section">
              <strong>Current Problem:</strong>
              <p>${escapeHTML(h.current_problem)}</p>
            </div>
          ` : ''}

          ${h.key_insights ? `
            <div class="handoff-section">
              <strong>Key Insights:</strong>
              <p>${escapeHTML(h.key_insights)}</p>
            </div>
          ` : ''}
        </div>
      `;
    }
  } else if (responseType === 'prompt_handoff') {
    title = 'Prompt Handoff';
    overlayClass = 'prompt-handoff';

    if (data.handoff) {
      const h = data.handoff;
      additionalContent = `
        <div class="handoff-sections">
          ${h.task_description ? `
            <div class="handoff-section">
              <strong>Task Description:</strong>
              <p>${escapeHTML(h.task_description)}</p>
            </div>
          ` : ''}

          ${h.implementation_steps && h.implementation_steps.length > 0 ? `
            <div class="handoff-section">
              <strong>Implementation Steps:</strong>
              <ol>
                ${h.implementation_steps.map(step => `<li>${escapeHTML(step)}</li>`).join('')}
              </ol>
            </div>
          ` : ''}

          ${h.technologies ? `
            <div class="handoff-section">
              <strong>Technologies:</strong>
              <p>${escapeHTML(h.technologies)}</p>
            </div>
          ` : ''}

          ${h.architecture ? `
            <div class="handoff-section">
              <strong>Architecture:</strong>
              <p>${escapeHTML(h.architecture)}</p>
            </div>
          ` : ''}

          ${h.code_context ? `
            <div class="handoff-section">
              <strong>Code Context:</strong>
              <p>${escapeHTML(h.code_context)}</p>
            </div>
          ` : ''}
        </div>
      `;
    }

    // Dodaj reasoning jeśli istnieje (dla prompt_handoff też może być)
    if (data.reasoning) {
      additionalContent += `
        <div class="overlay-reasoning">
          <strong>File Selection Reasoning:</strong>
          <p>${escapeHTML(data.reasoning)}</p>
        </div>
      `;
    }
  }

  return `
    <div class="gluon-response-overlay ${overlayClass} collapsed">
      <div class="gluon-overlay-header" role="button" tabindex="0">
        <span class="gluon-overlay-logo">⚡️</span>
        <span class="gluon-overlay-title">${title}</span>
        <span class="gluon-toggle-icon">▼</span>
      </div>
      <div class="gluon-overlay-expandable">
        <div class="gluon-overlay-content">
          ${additionalContent}
          <div class="overlay-files-section">
            <p><strong>Selected Files</strong> (${data.found.length})</p>
            <ul class="gluon-overlay-filelist">${filesHtml}</ul>
          </div>
        </div>
      </div>
      <div class="gluon-overlay-actions">
        <button class="gluon-btn-apply">Apply to Selection</button>
      </div>
    </div>
  `;
}

/**
 * Tworzy overlay częściowy
 */
function createPartialOverlay(data) {
  const responseType = data.responseType || 'auto_select';
  const foundHtml = data.found.map(f => `
    <li class="gluon-file-tile" data-filepath="${escapeHTML(f.path)}" data-project="${escapeHTML(f.project)}" style="cursor: pointer;" title="Click to find in file tree">
      <span class="file-icon">📄</span>
      <span class="file-path">${escapeHTML(f.path)}</span>
    </li>
  `).join('');
  const notFoundHtml = data.notFound.map(f => `
    <li class="gluon-file-tile-missing" data-filepath="${escapeHTML(f)}" style="cursor: pointer;" title="Click to search in file tree">
      <span class="file-icon-missing">✖️</span>
      <span class="file-path-missing">${escapeHTML(f)}</span>
    </li>
  `).join('');

  // Build additional content (reasoning/handoff) - same logic as success overlay
  let additionalContent = '';
  let overlayClass = '';
  let title = 'Partial Handoff';

  if (responseType === 'auto_select') {
    title = 'Partial Auto Select';
    if (data.reasoning) {
      additionalContent = `
        <div class="overlay-reasoning">
          <strong>Reasoning:</strong>
          <p>${escapeHTML(data.reasoning)}</p>
        </div>
      `;
    }
  } else if (responseType === 'context_handoff') {
    title = 'Partial Context Handoff';
    overlayClass = 'context-handoff';

    if (data.handoff) {
      const h = data.handoff;
      additionalContent = `
        <div class="handoff-sections">
          ${h.summary ? `<div class="handoff-section"><strong>Summary:</strong><p>${escapeHTML(h.summary)}</p></div>` : ''}
          ${h.solved_problems && h.solved_problems.length > 0 ? `<div class="handoff-section"><strong>Solved Problems:</strong><ul>${h.solved_problems.map(p => `<li>${escapeHTML(p)}</li>`).join('')}</ul></div>` : ''}
          ${h.current_problem ? `<div class="handoff-section"><strong>Current Problem:</strong><p>${escapeHTML(h.current_problem)}</p></div>` : ''}
          ${h.key_insights ? `<div class="handoff-section"><strong>Key Insights:</strong><p>${escapeHTML(h.key_insights)}</p></div>` : ''}
        </div>
      `;
    }
  } else if (responseType === 'prompt_handoff') {
    title = 'Partial Prompt Handoff';
    overlayClass = 'prompt-handoff';

    if (data.handoff) {
      const h = data.handoff;
      additionalContent = `
        <div class="handoff-sections">
          ${h.task_description ? `<div class="handoff-section"><strong>Task Description:</strong><p>${escapeHTML(h.task_description)}</p></div>` : ''}
          ${h.implementation_steps && h.implementation_steps.length > 0 ? `<div class="handoff-section"><strong>Implementation Steps:</strong><ol>${h.implementation_steps.map(step => `<li>${escapeHTML(step)}</li>`).join('')}</ol></div>` : ''}
          ${h.technologies ? `<div class="handoff-section"><strong>Technologies:</strong><p>${escapeHTML(h.technologies)}</p></div>` : ''}
          ${h.architecture ? `<div class="handoff-section"><strong>Architecture:</strong><p>${escapeHTML(h.architecture)}</p></div>` : ''}
          ${h.code_context ? `<div class="handoff-section"><strong>Code Context:</strong><p>${escapeHTML(h.code_context)}</p></div>` : ''}
        </div>
      `;
    }

    if (data.reasoning) {
      additionalContent += `<div class="overlay-reasoning"><strong>File Selection Reasoning:</strong><p>${escapeHTML(data.reasoning)}</p></div>`;
    }
  }

  return `
    <div class="gluon-response-overlay ${overlayClass} collapsed">
      <div class="gluon-overlay-header partial" role="button" tabindex="0">
        <span class="gluon-overlay-logo">⚡️</span>
        <span class="gluon-overlay-title">${title}</span>
        <span class="gluon-toggle-icon">▼</span>
      </div>
      <div class="gluon-overlay-expandable">
        <div class="gluon-overlay-content">
          ${additionalContent}
          <div class="overlay-files-section">
            <p><strong>Files Status:</strong> Found ${data.found.length} of ${data.found.length + data.notFound.length}</p>
            <div class="gluon-overlay-split-list">
              <div class="list-section"><strong>Found:</strong><ul class="gluon-overlay-filelist">${foundHtml}</ul></div>
              <div class="list-section"><strong>Not Found:</strong><ul class="gluon-overlay-filelist">${notFoundHtml}</ul></div>
            </div>
          </div>
        </div>
      </div>
      <div class="gluon-overlay-actions">
        <button class="gluon-btn-apply">Apply ${data.found.length} Found Files</button>
      </div>
    </div>
  `;
}

/**
 * Tworzy overlay błędu
 */
function createErrorOverlay(result) {
  return `
    <div class="gluon-response-overlay collapsed">
      <div class="gluon-overlay-header error" role="button" tabindex="0">
        <span class="gluon-overlay-logo">⚡️</span>
        <span class="gluon-overlay-title">Gluon Error</span>
        <span class="gluon-toggle-icon">▼</span>
      </div>
      <div class="gluon-overlay-expandable">
        <div class="gluon-overlay-content">
          <p><strong>${result.type.toUpperCase()} Error:</strong> ${escapeHTML(result.message)}</p>
        </div>
      </div>
    </div>
  `;
}

/**
 * Aplikuje selekcję z overlay
 */
export function handleApplySelection(payload) {
  parserLogger.log('===== APPLY SELECTION DEBUG =====');
  parserLogger.log('Full payload:', payload);

  const filesToSelect = payload.files;
  parserLogger.log('Applying selection from overlay:', filesToSelect);

  selectedNodes.clear();
  filesToSelect.forEach(file => {
    if (!selectedNodes.has(file.project)) {
      selectedNodes.set(file.project, new Set());
    }
    selectedNodes.get(file.project).add(file.path);
  });

  const dataToRender = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
  renderMergedFileTree(dataToRender);
  updateSelectionInfo();

  const quickTaskInput = document.getElementById('quickTaskInput');
  let actionTaken = false;

  if (payload.responseType === 'context_handoff' && payload.handoff && quickTaskInput) {
    actionTaken = true;
    const handoff = payload.handoff;

    const solvedProblemsText = Array.isArray(handoff.solved_problems) && handoff.solved_problems.length > 0
      ? `✅ Solved:\n${handoff.solved_problems.map(p => `- ${p}`).join('\n')}\n\n`
      : '';

    const formattedHandoff = `📋 CONTEXT HANDOFF:\n\nSummary: ${handoff.summary}\n\n${solvedProblemsText}🎯 Current: ${handoff.current_problem}\n\n${handoff.key_insights ? `💡 Insights: ${handoff.key_insights}` : ''}`;

    quickTaskInput.value = formattedHandoff;
    quickTaskInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
    quickTaskInput.style.background = 'rgba(139, 92, 246, 0.2)';
    setTimeout(() => { quickTaskInput.style.background = ''; }, 2000);
    showStatusMessage(`✅ Context handoff loaded to Quick Task!`, 'success');
  }

  if (payload.responseType === 'prompt_handoff' && payload.handoff && quickTaskInput) {
    actionTaken = true;
    const handoff = payload.handoff;
    const formattedPrompt = `=== TASK DESCRIPTION ===\n${handoff.task_description || ''}\n\n=== IMPLEMENTATION STEPS ===\n${(Array.isArray(handoff.implementation_steps) ? handoff.implementation_steps.map(s => `- ${s}`).join('\n') : '')}\n\n=== TECHNOLOGIES ===\n${handoff.technologies || ''}\n\n=== ARCHITECTURE ===\n${handoff.architecture || ''}\n\n=== CODE CONTEXT ===\n${handoff.code_context || ''}`;

    quickTaskInput.value = formattedPrompt;
    quickTaskInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
    quickTaskInput.style.background = 'rgba(0, 212, 255, 0.15)';
    setTimeout(() => { quickTaskInput.style.background = ''; }, 2000);
    showStatusMessage(`✅ Prompt loaded to Quick Task!`, 'success');
  }

  if (!actionTaken && filesToSelect.length > 0) {
    showStatusMessage(`✅ Applied selection of ${filesToSelect.length} files!`, 'success');
  }

  const firstFile = filesToSelect[0];
  if (firstFile) {
    const firstNode = document.querySelector(`.tree-node[data-path="${firstFile.path}"][data-project="${firstFile.project}"]`);
    if (firstNode) {
      firstNode.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }
}

/**
 * Obsługuje kliknięcie prompt generator
 */
export function handlePromptGeneratorClick() {
  const promptText = `w tej rozmowie tworzymy tylko plan. Kod będę pisał z innym modelem który otrzyma precyzyjny kontekst plików projektu, lub projektów. Napisz dla niego prompt bez podawania kodu. Model musi dostać prompt który określa zadanie i kierunek zadania, bardzo precyzyjnie, Ponieważ będzie pracował na mniejszym bardziej precyzyjnym kontekście. Teraz podaj prompt + [json] z plikami które uważasz za potrzebne przy zadaniu`;

  showStatusMessage('Pasting prompt generator instruction...', 'info');
  chrome.runtime.sendMessage({
    action: 'paste_prompt',
    payload: promptText
  });
}
