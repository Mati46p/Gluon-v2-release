import { sidebarLogger } from '../../common/logger.js';

// NOWA STRUKTURA: Przechowuje tylko niezmienne reguły formatowania i strukturę JSON
const PROMPT_FORMATS = {
  en: {
    auto_select: `{
  "@gluon:response": "auto_select",
  "@gluon:reasoning": "why these files",
  "@gluon:files": {
    "PROJECT_ID": ["path/to/file"]
  }
}`,
    context_handoff: `{
  "@gluon:response": "context_handoff",
  "@gluon:handoff": {
    "summary": "DETAILED CHRONOLOGY: Describe the entire thread's progress step-by-step...",
    "solved_problems": [
      "Problem 1: [problem description] | Solution: [detailed description] | Files: [modified files] | Rationale: [justification]"
    ],
    "current_problem": "CURRENT WORK STATUS: Describe in detail what is currently being worked on...",
    "key_insights": "CRITICAL CONTEXTUAL INFORMATION: Record all significant technical discoveries, architectural decisions..."
  },
  "@gluon:files": {
    "PROJECT_ID": ["path/to/file"]
  }
}`,
    prompt_handoff: `{
  "@gluon:response": "prompt_handoff",
  "@gluon:handoff": {
    "task_description": "[Detailed description of the task and its business/technical goal]",
    "implementation_steps": [
      "Step 1: Modify function X in file Y.",
      "Step 2: Add new component Z.",
      "Step 3: Update tests for component Z."
    ],
    "technologies": "[Key technologies, libraries, frameworks, and tools to be used]",
    "architecture": "[Description of how the new solution fits into the existing architecture, data flow, and component interactions]",
    "code_context": "[Critical information about existing, unattached code needed to understand the task]"
  },
  "@gluon:reasoning": "[Justification for the selection of attached files]",
  "@gluon:files": {
    "PROJECT_ID": ["path/to/file"]
  }
}`
  },
  pl: {
    auto_select: `{
  "@gluon:response": "auto_select",
  "@gluon:reasoning": "dlaczego te pliki",
  "@gluon:files": {
    "ID_PROJEKTU": ["sciezka/do/pliku"]
  }
}`,
    context_handoff: `{
  "@gluon:response": "context_handoff",
  "@gluon:handoff": {
    "summary": "SZCZEGÓŁOWA CHRONOLOGIA: Opisz krok po kroku cały przebieg wątku...",
    "solved_problems": [
      "Problem 1: [opis problemu] | Rozwiązanie: [szczegółowy opis] | Pliki: [zmodyfikowane pliki] | Dlaczego: [uzasadnienie]"
    ],
    "current_problem": "AKTUALNY STAN PRAC: Opisz szczegółowo nad czym obecnie trwają prace...",
    "key_insights": "KRYTYCZNE INFORMACJE KONTEKSTOWE: Zapisz wszystkie istotne odkrycia techniczne, decyzje architektoniczne..."
  },
  "@gluon:files": {
    "ID_PROJEKTU": ["sciezka/do/pliku"]
  }
}`,
    prompt_handoff: `{
  "@gluon:response": "prompt_handoff",
  "@gluon:handoff": {
    "task_description": "[Szczegółowy opis zadania i jego cel biznesowy/techniczny]",
    "implementation_steps": [
      "Krok 1: Zmodyfikuj funkcję X w pliku Y.",
      "Krok 2: Dodaj nowy komponent Z.",
      "Krok 3: Zaktualizuj testy dla komponentu Z."
    ],
    "technologies": "[Kluczowe technologie, biblioteki, frameworki i narzędzia, które należy wykorzystać]",
    "architecture": "[Opis, jak nowe rozwiązanie wpisuje się w istniejącą architekturę, jak przepływają dane i które komponenty się ze sobą komunikują]",
    "code_context": "[Krytyczne informacje o istniejącym kodzie, który nie jest załączony, ale jest niezbędny do zrozumienia zadania]"
  },
  "@gluon:reasoning": "[Uzasadnienie wyboru załączonych plików]",
  "@gluon:files": {
    "ID_PROJEKTU": ["sciezka/do/pliku"]
  }
}`
  }
};

const CRITICAL_RULES = {
  en: `CRITICAL RULES - RESPONSE FORMAT:
1. Your ENTIRE response must be a JSON object wrapped in a markdown code block with 'json' language identifier.
2. Start your response with: \`\`\`json
3. Then provide the complete JSON object following the RESPONSE FORMAT (JSON) structure shown above.
4. End your response with: \`\`\`
5. Do NOT include any text before or after the code block.
6. Use ONLY project IDs from the list of available projects (format: @gluon:project_name).
7. Provide relative paths from the project root (without a leading /).
8. String values in JSON must be properly escaped: \\" for quotes, \\\\ for backslashes, \\n for newlines.
9. **Never** use backticks (\`) inside JSON string values.

EXAMPLE OF CORRECT FORMAT:
\`\`\`json
{
  "@gluon:response": "auto_select",
  "@gluon:reasoning": "explanation here",
  "@gluon:files": {
    "@gluon:project_name": ["path/to/file.js"]
  }
}
\`\`\``,
  pl: `KRYTYCZNE ZASADY - FORMAT ODPOWIEDZI:
1. Twoja CAŁA odpowiedź musi być obiektem JSON zawiniętym w blok kodu markdown z identyfikatorem języka 'json'.
2. Rozpocznij odpowiedź od: \`\`\`json
3. Następnie podaj kompletny obiekt JSON zgodnie ze strukturą FORMAT ODPOWIEDZI (JSON) pokazaną powyżej.
4. Zakończ odpowiedź: \`\`\`
5. NIE dodawaj żadnego tekstu przed lub po bloku kodu.
6. Używaj TYLKO ID projektów z listy dostępnych projektów (format: @gluon:nazwa_projektu).
7. Podawaj ścieżki względne od roota projektu (bez początkowego /).
8. Wartości string w JSON muszą być poprawnie escapowane: \\" dla cudzysłowów, \\\\ dla backslashy, \\n dla nowych linii.
9. **Nigdy** nie używaj backtickόw (\`) wewnątrz wartości stringów JSON.

PRZYKŁAD POPRAWNEGO FORMATU:
\`\`\`json
{
  "@gluon:response": "auto_select",
  "@gluon:reasoning": "wyjaśnienie tutaj",
  "@gluon:files": {
    "@gluon:projekt": ["sciezka/do/pliku.js"]
  }
}
\`\`\``
};

const UI_LABELS = {
  en: {
    system_instructions: 'SYSTEM INSTRUCTIONS (BEHAVIOR DEFINITION)',
    response_format: 'RESPONSE FORMAT (JSON)',
    available_projects: 'AVAILABLE PROJECTS',
    user_task: 'USER TASK',
    no_projects: 'No projects selected.'
  },
  pl: {
    system_instructions: 'INSTRUKCJE SYSTEMOWE (DEFINICJA DZIAŁANIA)',
    response_format: 'FORMAT ODPOWIEDZI (JSON)',
    available_projects: 'DOSTĘPNE PROJEKTY',
    user_task: 'ZADANIE UŻYTKOWNIKA',
    no_projects: 'Brak wybranych projektów.'
  }
};

/**
// Modyfikacja całej funkcji/metody
 * Generates the full prompt string based on a new template system.
 * @param {string} type - 'auto_select', 'context_handoff', or 'prompt_handoff'.
 * @param {object} template - The SYSTEM template object from storage, containing task descriptions.
 * @param {Set<string>} selectedProjects - A set of selected project paths.
 * @param {string} userQuery - The actual query from the user chat.
 * @param {string} language - 'en' or 'pl'.
 * @returns {string} The complete prompt string.
 */
function generatePrompt(type, template, selectedProjects, userQuery, language = 'en') {
  const formats = PROMPT_FORMATS[language] || PROMPT_FORMATS['en'];
  const rules = CRITICAL_RULES[language] || CRITICAL_RULES['en'];
  const labels = UI_LABELS[language] || UI_LABELS['en'];

  if (!formats[type] || !template) {
    sidebarLogger.error(`Unknown prompt type or missing template: ${type}`);
    return '';
  }

  // 1. Generate {PROJECT_LIST}
  const projectList = Array.from(selectedProjects).map((path) => {
    const projectName = path.split(/[\/\\]/).pop() || path;
    const sanitizedName = projectName.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
    return `- @gluon:${sanitizedName}: ${path}`;
  }).join('\n');

  // Składanie finalnego promptu z 3 warstw
  const systemInstructionsLabel = labels.system_instructions;
  const responseFormatLabel = labels.response_format;
  const availableProjectsLabel = labels.available_projects;
  const userTaskLabel = labels.user_task;

  // Warstwa 1 (częściowo) i 2
  let systemPart = `
// ${systemInstructionsLabel}
${template.systemPrompt}

// ${responseFormatLabel}
${formats[type]}

// ${rules}

// ${availableProjectsLabel}
${projectList || labels.no_projects}
`;

  // Warstwa 3
  let userPart = `
// ${userTaskLabel}
${userQuery}
`;

  // Złożenie całości
  const finalPrompt = `${systemPart.trim()}\n\n---\n\n${userPart.trim()}`;

  return finalPrompt;
}

// Eksport funkcji do użycia w innych modułach
export { generatePrompt };