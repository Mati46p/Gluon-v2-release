import { sidebarLogger } from '../../common/logger.js';

/**
 * Calculates the Levenshtein distance between two strings.
 * @param {string} a The first string.
 * @param {string} b The second string.
 * @returns {number} The Levenshtein distance.
 */
function levenshteinDistance(a, b) {
    const matrix = Array(b.length + 1).fill(null).map(() => Array(a.length + 1).fill(null));
    for (let i = 0; i <= a.length; i += 1) { matrix[0][i] = i; }
    for (let j = 0; j <= b.length; j += 1) { matrix[j][0] = j; }
    for (let j = 1; j <= b.length; j += 1) {
        for (let i = 1; i <= a.length; i += 1) {
            const indicator = a[i - 1] === b[j - 1] ? 0 : 1;
            matrix[j][i] = Math.min(
                matrix[j][i - 1] + 1,      // deletion
                matrix[j - 1][i] + 1,      // insertion
                matrix[j - 1][i - 1] + indicator, // substitution
            );
        }
    }
    return matrix[b.length][a.length];
}

/**
 * Main parsing pipeline for handling responses from the AI model.
 * @param {string} rawText The raw text from the AI's response.
 * @param {Array<object>} fileTreeData The current file tree data for validation.
 * @param {Array<object>} allAvailableProjects The complete list of all known projects.
 * @returns {object} A result object with status and parsed data.
 */
function parseGluonResponse(rawText, fileTreeData, allAvailableProjects) {
    sidebarLogger.log('Starting parsing pipeline...');
    
    let jsonObject;
    try {
        const jsonMatch = rawText.match(/```(?:json)?\s*([\s\S]+?)\s*```|(\{[\s\S]+\})/);
        if (!jsonMatch) {
            return { status: 'error', type: 'format', message: 'No JSON block found in the response.' };
        }
        const jsonString = jsonMatch[1] || jsonMatch[2];
        jsonObject = JSON.parse(jsonString);
    } catch (error) {
        return { status: 'error', type: 'format', message: `Invalid JSON format: ${error.message}` };
    }

    const responseType = jsonObject['@gluon:response'];
    if (!responseType || !jsonObject['@gluon:files']) {
        return { status: 'error', type: 'format', message: 'Response is missing required keys: "@gluon:response" or "@gluon:files".' };
    }
    sidebarLogger.log('Layer 3: Schema Validation ✓');

    // Layer 4: File Validation
    const allProjectFiles = new Map();
    
    const collectFiles = (nodes, paths = new Set()) => {
        for (const node of nodes) {
            if (node.nodeType === 'file') {
                paths.add(node.path.replace(/\\/g, '/'));
            } else if (node.children) {
                collectFiles(node.children, paths);
            }
        }
        return paths;
    };

    fileTreeData.forEach(project => {
        if (project.tree) {
            allProjectFiles.set(project.projectPath, collectFiles(project.tree));
        }
    });

    const validationResult = {
        found: [],
        notFound: [],
        suggestions: [],
    };

    const projectMapping = new Map();
    const projectsToMap = allAvailableProjects && allAvailableProjects.length > 0
        ? allAvailableProjects
        : fileTreeData.map(p => ({ path: p.projectPath }));

    projectsToMap.forEach((project) => {
        const projectPath = project.path || project.projectPath;
        if (!projectPath) return;
        const projectName = projectPath.split(/[\\/]/).pop() || projectPath;
        const sanitizedName = projectName.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
        const gluonKey = `@gluon:${sanitizedName}`;
        
        projectMapping.set(gluonKey, projectPath);
        projectMapping.set(projectName, projectPath);
    });
    
    sidebarLogger.log('Project Mapping:', Object.fromEntries(projectMapping));

    for (const [gluonKey, fileList] of Object.entries(jsonObject['@gluon:files'])) {
        const projectPath = projectMapping.get(gluonKey);
        sidebarLogger.log(`Processing key: ${gluonKey}, ProjectPath: ${projectPath}`);
        
        if (!projectPath) {
            fileList.forEach(file => validationResult.notFound.push({ 
                project: gluonKey, 
                path: file, 
                reason: 'Unknown project key' 
            }));
            continue;
        }

        const availableFiles = allProjectFiles.get(projectPath);
        if (!availableFiles) {
            sidebarLogger.log(`❌ Project not loaded (not in fileTreeData): ${projectPath} (Key: ${gluonKey})`);
            fileList.forEach(filePath => {
                 validationResult.notFound.push({ project: projectPath, path: filePath, reason: 'Project not loaded' });
            });
            continue;
        }

        fileList.forEach(filePath => {
            const normalizedPath = filePath.replace(/\\/g, '/');
            if (availableFiles.has(normalizedPath)) {
                validationResult.found.push({ project: projectPath, path: normalizedPath });
            } else {
                let suggestion = null;
                let minDistance = 4; // Levenshtein distance threshold
                for (const availableFile of availableFiles) {
                    const distance = levenshteinDistance(normalizedPath, availableFile);
                    if (distance < minDistance) {
                        minDistance = distance;
                        suggestion = availableFile;
                    }
                }
                validationResult.notFound.push({ project: projectPath, path: normalizedPath, reason: 'File not found' });
                if (suggestion) {
                    validationResult.suggestions.push({ from: normalizedPath, to: suggestion });
                }
            }
        });
    }

    sidebarLogger.log('Layer 4: File Validation ✓', validationResult);

    const hasFound = validationResult.found.length > 0;
    const hasNotFound = validationResult.notFound.length > 0;

    const responseData = {
        files: validationResult.found,
        responseType: responseType
    };
    
    // Zaktualizowana logika do obsługi różnych typów odpowiedzi
    if (jsonObject['@gluon:reasoning']) {
        responseData.reasoning = jsonObject['@gluon:reasoning'];
    }
    if (jsonObject['@gluon:handoff']) {
        responseData.handoff = jsonObject['@gluon:handoff'];
    }

    if (!hasNotFound) {
        return { status: 'success', data: responseData };
    }

    if (hasFound && hasNotFound) {
        return {
            status: 'partial',
            data: {
                ...responseData,
                notFound: validationResult.notFound,
                suggestions: validationResult.suggestions
            }
        };
    }

    if (!hasFound && hasNotFound) {
        const allUnknownProjects = validationResult.notFound.every(
            file => file.reason === 'Unknown project key'
        );
        let errorMessage = 'None of the requested files could be found.';
        
        if (allUnknownProjects) {
            const unknownKeys = [...new Set(validationResult.notFound.map(f => f.project))].join('", "');
            errorMessage = `The following requested project(s) are not loaded or do not exist: "${unknownKeys}". Please select the correct projects in Gluon.`;
        } else if (validationResult.notFound.length > 0) {
            errorMessage = 'Some requested files were not found in the loaded projects.';
        }

        return { 
            status: 'error', 
            type: 'files', 
            message: errorMessage,
            data: validationResult 
        };
    }
    
    return { status: 'error', type: 'unknown', message: 'An unknown error occurred during parsing.', data: validationResult };
}