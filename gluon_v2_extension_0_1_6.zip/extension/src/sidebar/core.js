// ============================================================================
// Gluon Sidebar - Main Entry Point
// Punkt wejścia aplikacji, importuje wszystkie moduły i inicjalizuje UI
// ============================================================================

// Import logger
import { sidebarLogger } from '../common/logger.js';

// Import state management
import {
  fileTreeData, selectedNodes, selectedProjects, allProjects, pendingConfigRestore,
  selectedEnvironmentId, enabledPromptIds, licenseStatus,
  setFileTreeData, setAllProjects, setLicenseStatus, setSelectedEnvironmentId,
  setEnabledPromptIds, setPendingConfigRestore, setEnvironments,
  loadStateFromStorage, loadActiveTemplates, handleCheckboxChange, handleLogsCheckboxChange,
  updateBlockingOverlay, updateConnectionStatus, applyTheme,
  showLoading, hideLoading, showError, showStatusMessage
} from './management/stateManagement.js';

// Import file tree management
import {
  populateProjects, handleDeselectAllProjects, triggerFileTreeLoadForSelected,
  handleSearch, handleClearSelection, updateSelectionInfo,
  setupFileTreeResizer, updateFileCount,
  renderMergedFileTree, constructMultiProjectPayload,
  loadEnvironmentForSelectedProjects
} from './management/fileTreeManagement.js';

// Import context management
import {
  loadContextHistory, renderContextHistoryList, handleShowMoreContext,
  handleGenerateContextFile, handleGenerateSimpleFile, handleFileCopyResponse, parseAttachedFilesFromContext,
  initQuickTaskHistory, handleQuickTaskHistoryKeydown
} from './management/contextManagement.js';

// Import template & prompt management
import {
  setupEnvironmentListeners, loadEnvironments, populateEnvironments,
  loadTemplates, showCreateTemplateModal, hideCreateTemplateModal,
  saveTemplate, deleteTemplate, showManageTemplatesModal, hideManageTemplatesModal,
  handleManageTemplatesClick, updateDynamicTemplateFields,
  showPromptInputModal, hidePromptInputModal, handlePromptModalSubmit,
  handlePromptHistoryKeydown, renderPrompts, resetToDefaultEnvironment,
  setEnvironmentForProject
} from './management/templatePromptManagement.js';

// Import AI integration
import {
  handleAutoSelect, handleDetectedResponse, handleApplySelection,
  handlePromptGeneratorClick
} from './management/aiIntegrationCommandParsing.js';

// ============================================================================
// Initialization
// ============================================================================

document.addEventListener('DOMContentLoaded', async () => {
  sidebarLogger.log('Sidebar initializing...');
  chrome.runtime.sendMessage({ action: 'init_connection' });
  setupEventListeners();
  chrome.storage.local.get(['uiThemeSettings'], (result) => {
    if (result.uiThemeSettings) {
      sidebarLogger.debug('Stosowanie motywu z pamięci lokalnej:', result.uiThemeSettings);
      applyTheme(result.uiThemeSettings);
    }
  });
  await loadStateFromStorage();
  await loadTemplates();
  await loadActiveTemplates();
  updateBlockingOverlay();
});

// ============================================================================
// Event Listeners Setup
// ============================================================================

function setupEventListeners() {
  sidebarLogger.log('🔧 Setting up event listeners...');

  // Logo click
  const headerLeft = document.querySelector('.header-left');
  if (headerLeft) {
    headerLeft.style.cursor = 'pointer';
    headerLeft.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://ai-gluon.com' });
    });
    sidebarLogger.debug('✅ Header link listener attached');
  }

  const overlayLogo = document.getElementById('overlay-logo');
  if (overlayLogo) {
    overlayLogo.addEventListener('click', () => {
      const title = document.getElementById('overlay-title');
      if (title) {
        title.textContent = 'Checking Status...';
      }
      chrome.runtime.sendMessage({ action: 'init_connection' });
    });
    sidebarLogger.debug('✅ Overlay logo refresh listener attached');
  }

  // Deselectuj wszystkie projekty
  const deselectBtn = document.getElementById('deselectAllBtn');
  if (deselectBtn) {
    deselectBtn.addEventListener('click', handleDeselectAllProjects);
    sidebarLogger.debug('✅ Deselect button listener attached');
  }

  // Search input
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', handleSearch);
    sidebarLogger.debug('✅ Search input listener attached');
  }

  // Clear selection
  const clearSelectionBtn = document.getElementById('clearSelection');
  if (clearSelectionBtn) {
    clearSelectionBtn.addEventListener('click', handleClearSelection);
    sidebarLogger.debug('✅ Clear selection listener attached');
  }

  // Copy button
  const copyBtn = document.getElementById('copyBtn');
  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      const { handleCopyFiles } = await import('./management/contextManagement.js');
      handleCopyFiles();
    });
    sidebarLogger.debug('✅ Copy button listener attached');
  }

  // Generate button
  const generateBtn = document.getElementById('generateBtn');
  if (generateBtn) {
    generateBtn.addEventListener('click', () => {
      try {
        handleGenerateContextFile();
      } catch (error) {
        sidebarLogger.error('Error calling handleGenerateContextFile:', error);
        showStatusMessage(`Error: ${error.message}`, 'error');
      }
    });
  }

  // Generate Simple button (files only)
  const generateSimpleBtn = document.getElementById('generateSimpleBtn');
  if (generateSimpleBtn) {
    generateSimpleBtn.addEventListener('click', () => {
      try {
        handleGenerateSimpleFile();
      } catch (error) {
        sidebarLogger.error('Error calling handleGenerateSimpleFile:', error);
        showStatusMessage(`Error: ${error.message}`, 'error');
      }
    });
    sidebarLogger.debug('✅ Generate Simple button listener attached');
  }

  // Show more context files button
  const showMoreBtn = document.getElementById('showMoreContextBtn');
  if (showMoreBtn) {
    showMoreBtn.addEventListener('click', handleShowMoreContext);
    sidebarLogger.debug('✅ Show more context button listener attached');
  }

  // Connection indicator
  const connectionIndicator = document.getElementById('connectionIndicator');
  if (connectionIndicator) {
    connectionIndicator.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'init_connection' });
    });
    sidebarLogger.debug('✅ Connection indicator listener attached');
  }

  // Checkboxes
  const includeStructureCheckbox = document.getElementById('includeStructure');
  if (includeStructureCheckbox) {
    includeStructureCheckbox.addEventListener('change', (e) => {
      handleCheckboxChange(e);
      updateSelectionInfo();
    });
  }

  const includeLogsCheckbox = document.getElementById('includeLogs');
  if (includeLogsCheckbox) {
    includeLogsCheckbox.addEventListener('change', handleLogsCheckboxChange);
    sidebarLogger.debug('✅ Include logs checkbox listener attached');
  }

  // Template buttons
  const autoSelectBtn = document.getElementById('autoSelectBtn');
  const contextHandoffBtn = document.getElementById('contextHandoffBtn');
  const promptHandoffBtn = document.getElementById('promptHandoffBtn');

  if (autoSelectBtn) {
    autoSelectBtn.addEventListener('click', () => showPromptInputModal('auto_select'));
  }

  if (contextHandoffBtn) {
    contextHandoffBtn.addEventListener('click', () => showPromptInputModal('context_handoff'));
  }

  if (promptHandoffBtn) {
    promptHandoffBtn.addEventListener('click', () => showPromptInputModal('prompt_handoff'));
  }

  const manageTemplatesBtn = document.getElementById('manageTemplatesBtn');
  if (manageTemplatesBtn) {
    manageTemplatesBtn.addEventListener('click', showManageTemplatesModal);
  }

  // Create Template Modal
  const createTemplateModal = document.getElementById('createTemplateModal');
  const createTemplateForm = document.getElementById('createTemplateForm');
  const cancelTemplateBtn = document.getElementById('cancelTemplateBtn');
  const deleteTemplateBtn = document.getElementById('deleteTemplateBtn');

  if (deleteTemplateBtn) {
    deleteTemplateBtn.addEventListener('click', (e) => {
      const type = e.target.dataset.type;
      const id = e.target.dataset.id;
      const name = document.getElementById('templateName').value;

      if (type && id && confirm(`Are you sure you want to delete the template "${name}"?`)) {
        deleteTemplate(type, id);
        hideCreateTemplateModal();
      }
    });
  }

  if (cancelTemplateBtn) {
    cancelTemplateBtn.addEventListener('click', hideCreateTemplateModal);
  }

  if (createTemplateModal) {
    createTemplateModal.addEventListener('click', (e) => {
      if (e.target === createTemplateModal) {
        hideCreateTemplateModal();
      }
    });
  }

  if (createTemplateForm) {
    createTemplateForm.addEventListener('submit', (e) => {
      e.preventDefault();
      saveTemplate();
    });
  }

  // Manage Templates Modal
  const manageTemplatesModal = document.getElementById('manageTemplatesModal');
  const closeManageModalBtn = document.getElementById('closeManageModalBtn');
  const createNewTemplateFromManageBtn = document.getElementById('createNewTemplateFromManageBtn');

  if (closeManageModalBtn) {
    closeManageModalBtn.addEventListener('click', hideManageTemplatesModal);
  }
  if (manageTemplatesModal) {
    manageTemplatesModal.addEventListener('click', (e) => {
      if (e.target === manageTemplatesModal) hideManageTemplatesModal();
    });
    manageTemplatesModal.addEventListener('click', handleManageTemplatesClick);
  }
  if (createNewTemplateFromManageBtn) {
    createNewTemplateFromManageBtn.addEventListener('click', () => {
      hideManageTemplatesModal();
      const activeTab = document.querySelector('#manageTemplatesModal .tab-link.active');
      let type = activeTab ? activeTab.dataset.tab : 'auto_select';

      if (type.startsWith('tab-')) {
        type = type.substring(4);
      }

      showCreateTemplateModal(type);
    });
  }

  // Prompt Input Modal
  const promptInputModal = document.getElementById('promptInputModal');
  const promptInputForm = document.getElementById('promptInputForm');
  const cancelPromptModalBtn = document.getElementById('cancelPromptModalBtn');
  const modalPromptTextarea = document.getElementById('modalPromptTextarea');

  if (cancelPromptModalBtn) {
    cancelPromptModalBtn.addEventListener('click', hidePromptInputModal);
  }
  if (promptInputModal) {
    promptInputModal.addEventListener('click', (e) => {
      if (e.target === promptInputModal) {
        hidePromptInputModal();
      }
    });
  }
  if (promptInputForm) {
    promptInputForm.addEventListener('submit', handlePromptModalSubmit);
  }
  if (modalPromptTextarea) {
    modalPromptTextarea.addEventListener('keydown', handlePromptHistoryKeydown);
  }

  // Quick Task History
  const quickTaskInput = document.getElementById('quickTaskInput');
  if (quickTaskInput) {
    quickTaskInput.addEventListener('keydown', handleQuickTaskHistoryKeydown);
  }

  setupEnvironmentListeners();
  loadContextHistory();
  setupFileTreeResizer();
  initQuickTaskHistory();

  sidebarLogger.success('All event listeners setup complete');
}

// ============================================================================
// Message Handling from Background
// ============================================================================

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  switch (message.type) {
    case 'status_update':
      updateConnectionStatus(message.status);
      break;
    case 'license_status_loaded':
      const { status, themeName, theme80sColor1, theme80sColor2 } = message.data;

      setLicenseStatus(status || 'MISSING');
      updateBlockingOverlay();

      const themeSettings = { themeName, theme80sColor1, theme80sColor2 };
      applyTheme(themeSettings);
      chrome.storage.local.set({ uiThemeSettings: themeSettings });
      break;
    case 'projects_loaded':
      setAllProjects(message.data || []);
      const { restoreSelectedProjects } = await import('./management/stateManagement.js');
      await restoreSelectedProjects();
      populateProjects(message.data);
      await loadEnvironmentForSelectedProjects();
      triggerFileTreeLoadForSelected();
      break;
    case 'environments_loaded':
      setEnvironments(message.data || []);
      populateEnvironments();
      break;
    case 'project_environment_loaded':
      await setEnvironmentForProject(message.data);
      break;
    case 'file_trees_loaded':
      const { currentFileTreeRequestId } = await import('./management/stateManagement.js');
      if (currentFileTreeRequestId && message.request_id !== currentFileTreeRequestId) {
        sidebarLogger.debug('Ignoring file_trees_loaded - request ID mismatch');
        return;
      }

      setFileTreeData(message.data || []);

      if (pendingConfigRestore) {
        selectedNodes.clear();
        for (const [projectPath, files] of Object.entries(pendingConfigRestore.selectedFiles)) {
          selectedNodes.set(projectPath, new Set(files));
        }
        setPendingConfigRestore(null);
        sidebarLogger.debug('Restored selected files from config');
      }

      // Apply search filter if search is active
      const { searchQuery } = await import('./management/stateManagement.js');
      const { filterFileTree } = await import('./management/fileTreeManagement.js');
      const dataToRender = searchQuery ? filterFileTree(fileTreeData) : fileTreeData;
      renderMergedFileTree(dataToRender);
      updateFileCount();
      hideLoading('generateBtn');
      const { setCurrentFileTreeRequestId } = await import('./management/stateManagement.js');
      setCurrentFileTreeRequestId(null);
      break;
    case 'files_multi_content_loaded':
      handleFileCopyResponse(message.data);
      hideLoading('copyBtn');
      break;
    case 'context_file_generated':
      setTimeout(() => {
        hideLoading('generateBtn');
        hideLoading('generateSimpleBtn');
      }, 2000);

      const filepath = message.data?.filepath;
      const filename = message.data?.filename;

      if (!filepath || !filename) {
        showStatusMessage('Error: Context file generated but path/filename is missing.', 'error');
        return;
      }

      showStatusMessage(`✅ File saved: ${filename}`, 'success');
      sidebarLogger.log('Context file saved at:', filepath);

      const { attachContextFile } = await import('./management/contextManagement.js');
      // Po wygenerowaniu pliku od razu go załącz
      attachContextFile(filepath, filename);
      setTimeout(() => loadContextHistory(), 500);
      break;
    case 'context_history_loaded':
      renderContextHistoryList(message.data);
      break;
    case 'context_file_content_ready':
      chrome.runtime.sendMessage({
        action: 'inject_file_to_gemini',
        payload: {
          filename: message.data.filename,
          content: message.data.content,
          type: 'text/plain'
        }
      });

      const attachedFiles = parseAttachedFilesFromContext(message.data.content);

      if (attachedFiles.length > 0) {
        showStatusMessage(`✅ ${message.data.filename} attached! Attaching ${attachedFiles.length} binary file(s)...`, 'success');

        attachedFiles.forEach(fileToAttach => {
          const project = allProjects.find(p => p.path.endsWith(fileToAttach.projectName));

          if (project) {
            const fullPath = `${project.path.replace(/\\/g, '/')}/${fileToAttach.relativePath}`;
            sidebarLogger.debug(`Requesting binary attachment from context: ${fullPath}`);

            chrome.runtime.sendMessage({
              action: 'get_binary_file_for_upload',
              payload: {
                filepath: fullPath
              }
            });
          } else {
            sidebarLogger.warn(`Could not find project matching name: '${fileToAttach.projectName}'`);
            showStatusMessage(`Warning: Project '${fileToAttach.projectName}' not found for attachment.`, 'error');
          }
        });

      } else {
        showStatusMessage(`✅ ${message.data.filename} attached!`, 'success');
      }

      sendResponse({ success: true });
      break;
    case 'gluon_command_detected':
      handleAutoSelect(message.files, message.clearPrevious);
      sendResponse({ success: true });
      break;
    case 'gluon_response_detected':
      handleDetectedResponse(message.payload);
      break;
    case 'apply_gluon_selection':
      handleApplySelection(message.payload);
      break;
    case 'search_file_in_tree':
      handleSearchFileInTree(message.payload);
      break;
    case 'error':
      showError(message.message);
      setTimeout(() => {
        hideLoading('generateBtn');
        hideLoading('generateSimpleBtn');
        hideLoading('copyBtn');
      }, 2000);
      break;
  }
  return true;
});

/**
 * Obsługuje wyszukiwanie pliku w drzewie po kliknięciu kafelka
 */
function handleSearchFileInTree(payload) {
  const { filePath, projectPath, isMissing } = payload;
  sidebarLogger.log('Searching for file in tree:', { filePath, projectPath, isMissing });

  // Use search to find the file by filename (works even if file is in collapsed folder)
  const fileName = filePath.split('/').pop();
  const searchInput = document.getElementById('searchInput');

  if (searchInput) {
    searchInput.value = fileName;
    searchInput.dispatchEvent(new Event('input', { bubbles: true }));

    // Wait a bit for the search to render, then try to find and highlight the file
    setTimeout(() => {
      const fileNode = document.querySelector(
        `.tree-node.file[data-path="${filePath}"]${projectPath ? `[data-project="${projectPath}"]` : ''}`
      );

      if (fileNode) {
        fileNode.scrollIntoView({ behavior: 'smooth', block: 'center' });

        // Add temporary highlight
        fileNode.style.background = 'rgba(139, 92, 246, 0.3)';
        fileNode.style.transition = 'background 0.3s ease';

        setTimeout(() => {
          fileNode.style.background = '';
        }, 2000);

        showStatusMessage(`📄 Found: ${fileName}`, 'success');
      } else {
        // Scroll to search input to show results
        searchInput.scrollIntoView({ behavior: 'smooth', block: 'start' });

        if (isMissing) {
          showStatusMessage(`⚠️ File not found, searching for: ${fileName}`, 'info');
        } else {
          showStatusMessage(`🔍 Searching for: ${fileName}`, 'info');
        }
      }

      // Highlight search input
      searchInput.style.background = 'rgba(255, 193, 7, 0.2)';
      setTimeout(() => {
        searchInput.style.background = '';
      }, 1500);
    }, 300);
  }
}

sidebarLogger.success('Gluon Sidebar loaded');
