/**
 * Creates the HTML for the success overlay.
 * @param {object} data - The parsed response data from the parser.
 * @returns {string} The HTML string for the overlay.
 */
function createSuccessOverlay(data) {
    // Check response type and render accordingly
    if (data.responseType === 'context_handoff') {
        return createContextHandoffOverlay(data);
    }
    if (data.responseType === 'prompt_handoff') {
        return createPromptHandoffOverlay(data);
    }
    
    // Default: auto_select overlay
    const filesByProject = data.files.reduce((acc, file) => {
        const projectName = file.project.split(/[\\/]/).pop();
        if (!acc[projectName]) acc[projectName] = [];
        acc[projectName].push(file.path);
        return acc;
    }, {});

    const fileLists = Object.entries(filesByProject).map(([projectName, files]) => `
        <div class="files-list">
            <strong>${projectName} (${files.length}):</strong>
            <ul>
                ${files.map(path => `<li>${path}</li>`).join('')}
            </ul>
        </div>
    `).join('');

    return `
    <div class='gluon-response-overlay'>
        <div class='overlay-header'>🎯 Gluon Auto-Select</div>
        <div class='overlay-body'>
            <div class='reasoning'>
                <strong>Reasoning:</strong> ${data.reasoning || 'No reasoning provided.'}
            </div>
            ${fileLists}
        </div>
        <div class='overlay-actions'>
            <button class='gluon-btn-apply'>✔ Select All (${data.files.length})</button>
            <button class='gluon-btn-ignore'>✗ Ignore</button>
        </div>
    </div>`;
}

/**
 * Creates the HTML for context handoff overlay.
 * @param {object} data - The parsed context handoff data.
 * @returns {string} The HTML string for the overlay.
 */
function createContextHandoffOverlay(data) {
    const handoff = data.handoff;
    
    const filesByProject = data.files.reduce((acc, file) => {
        const projectName = file.project.split(/[\\/]/).pop();
        if (!acc[projectName]) acc[projectName] = [];
        acc[projectName].push(file.path);
        return acc;
    }, {});

    const fileLists = Object.entries(filesByProject).map(([projectName, files]) => `
        <div class="files-list">
            <strong>${projectName} (${files.length}):</strong>
            <ul>
                ${files.map(path => `<li>${path}</li>`).join('')}
            </ul>
        </div>
    `).join('');
    
    const solvedProblemsHtml = handoff.solved_problems && handoff.solved_problems.length > 0 
        ? `<div class="handoff-section">
            <strong>✅ Solved:</strong>
            <ul>${handoff.solved_problems.map(p => `<li>${p}</li>`).join('')}</ul>
           </div>`
        : '';
    
    const keyInsightsHtml = handoff.key_insights 
        ? `<div class="handoff-section">
            <strong>💡 Key Insights:</strong>
            <p>${handoff.key_insights}</p>
           </div>`
        : '';

    return `
    <div class='gluon-response-overlay context-handoff'>
        <div class='overlay-header'>📋 Context Handoff</div>
        <div class='overlay-body'>
            <div class="handoff-section">
                <strong>📝 Summary:</strong>
                <p>${handoff.summary || 'No summary provided.'}</p>
            </div>
            ${solvedProblemsHtml}
            <div class="handoff-section">
                <strong>🎯 Current Problem:</strong>
                <p>${handoff.current_problem || 'Not specified.'}</p>
            </div>
            <div class="handoff-section">
                <strong>➡️ Next Steps:</strong>
                <p>${handoff.next_steps || 'Not specified.'}</p>
            </div>
            ${keyInsightsHtml}
            <div class="found-files">
                <strong>Files to attach (${data.files.length}):</strong>
                ${fileLists}
            </div>
        </div>
        <div class='overlay-actions'>
            <button class='gluon-btn-apply'>✔ Select All Files (${data.files.length})</button>
            <button class='gluon-btn-ignore'>✗ Dismiss</button>
        </div>
    </div>`;
}

/**
 * Creates the HTML for the prompt handoff overlay.
 * @param {object} data - The parsed prompt handoff data.
 * @returns {string} The HTML string for the overlay.
 */
function createPromptHandoffOverlay(data) {
    const filesByProject = data.files.reduce((acc, file) => {
        const projectName = file.project.split(/[\\/]/).pop();
        if (!acc[projectName]) acc[projectName] = [];
        acc[projectName].push(file.path);
        return acc;
    }, {});

    const fileLists = Object.entries(filesByProject).map(([projectName, files]) => `
        <div class="files-list">
            <strong>${projectName} (${files.length}):</strong>
            <ul>
                ${files.map(path => `<li>${path}</li>`).join('')}
            </ul>
        </div>
    `).join('');

    const escapeHtml = (unsafe) => {
        if (!unsafe) return '';
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };

    return `
    <div class='gluon-response-overlay prompt-handoff'>
        <div class='overlay-header'>🤖 AI Prompt Generated</div>
        <div class='overlay-body'>
            <div class='reasoning'>
                <strong>Reasoning:</strong> ${escapeHtml(data.reasoning)}
            </div>
            <div class="prompt-preview">
                <strong>Prompt Preview:</strong>
                <pre style="white-space: pre-wrap; word-wrap: break-word;"><code>${escapeHtml(data.prompt)}</code></pre>
            </div>
            <div class="found-files">
                <strong>Files to attach (${data.files.length}):</strong>
                ${fileLists}
            </div>
        </div>
        <div class='overlay-actions'>
            <button class="gluon-btn-apply">✔ Select Files & Copy Prompt</button>
            <button class='gluon-btn-ignore'>✗ Dismiss</button>
        </div>
    </div>`;
}

/**
 * Creates the HTML for the partial success overlay.
 * @param {object} data - The parsed response data with found, notFound, and suggestions.
 * @returns {string} The HTML string for the overlay.
 */
function createPartialOverlay(data) {
    const foundFiles = data.files || [];
    const notFoundFiles = data.notFound || [];
    
    // Determine overlay type
    const isContextHandoff = data.responseType === 'context_handoff';
    const isPromptHandoff = data.responseType === 'prompt_handoff';

    let headerIcon = '🎯';
    let headerText = 'Gluon Request - Partial Match';
    if (isContextHandoff) {
        headerIcon = '📋';
        headerText = 'Context Handoff - Partial Match';
    } else if (isPromptHandoff) {
        headerIcon = '🤖';
        headerText = 'AI Prompt - Partial Match';
    }

    // Grupuj pliki według projektów
    const foundByProject = foundFiles.reduce((acc, file) => {
        const projectName = file.project.split(/[\\/]/).pop();
        if (!acc[projectName]) acc[projectName] = [];
        acc[projectName].push(file);
        return acc;
    }, {});

    const notFoundByProject = notFoundFiles.reduce((acc, file) => {
        // Dla 'nieznalezionych' klucz może być ID Gluon, a nie ścieżką
        const projectName = file.reason === 'Unknown project key' 
            ? file.project // Pokaż "@gluon:nazwa"
            : file.project.split(/[\\/]/).pop();
        if (!acc[projectName]) acc[projectName] = [];
        acc[projectName].push(file);
        return acc;
    }, {});

    const foundList = foundFiles.length > 0 ? `
    <div class='found-files'>
        <strong>✓ Found (${foundFiles.length}):</strong>
        ${Object.entries(foundByProject).map(([projectName, files]) => `
            <div class="files-list">
                <strong>${projectName} (${files.length}):</strong>
                <ul>
                    ${files.map(f => `<li>${f.path}</li>`).join('')}
                </ul>
            </div>
        `).join('')}
    </div>` : '';

    const notFoundList = notFoundFiles.length > 0 ? `
    <div class='not-found-files'>
        <strong>✗ Not found (${notFoundFiles.length}):</strong>
        ${Object.entries(notFoundByProject).map(([projectName, files]) => `
            <div class="files-list">
                <strong>${projectName} (${files.length}):</strong>
                <ul>
                    ${files.map(f => `<li>${f.path} - <em>${f.reason}</em></li>`).join('')}
                </ul>
            </div>
        `).join('')}
    </div>` : '';
    
    let contextInfo = '';
    if (isContextHandoff && data.handoff) {
        contextInfo = `
        <div class="handoff-summary">
            <strong>📝 Summary:</strong>
            <p>${data.handoff.summary}</p>
        </div>`;
    } else if (data.reasoning) {
        contextInfo = `
        <div class='reasoning'>
            <strong>Reasoning:</strong> ${data.reasoning}
        </div>`;
    }

    // --- DYNAMIC BUTTON LOGIC ---
    let buttonAttrs = `class='gluon-btn-apply'`; // Usunięto atrybuty data-*
    let buttonText = `✔ Select Found (${(data.files || []).length})`;

    // Logika do ustalenia tekstu przycisku pozostaje, ale bez atrybutów
    if (data.responseType === 'context_handoff' && data.handoff) {
        // buttonAttrs bez zmian
    } else if (data.responseType === 'prompt_handoff' && data.prompt) {
        buttonText = `✔ Select Found & Copy Prompt`;
    }

    return `
    <div class='gluon-response-overlay partial ${data.responseType === 'context_handoff' ? 'context-handoff' : ''}'>
        <div class='overlay-header'>${headerIcon} ${headerText}</div>
        <div class='overlay-body'>
             ${contextInfo}
             <div class="found-split">${foundList}${notFoundList}</div>
        </div>
        <div class='overlay-actions'>
            <button ${buttonAttrs}>${buttonText}</button>
            <button class='gluon-btn-ignore'>✗ Ignore</button>
        </div>
    </div>`;
}

/**
 * Creates the HTML for the error overlay.
 * @param {object} data - The error data from the parser.
 * @returns {string} The HTML string for the overlay.
 */
function createErrorOverlay(data) {
    let detailsHtml = '';
    // data.data to obiekt validationResult przekazany z parsera
    if (data.data && data.data.notFound && data.data.notFound.length > 0) {
        detailsHtml = `
        <div class='not-found-files' style="margin-top: 10px;">
            <strong>✗ Failed Files (${data.data.notFound.length}):</strong>
            <ul>${data.data.notFound.map(f => `<li>${f.path} - <em>${f.reason}</em></li>`).join('')}</ul>
        </div>`;
    }

    return `
    <div class='gluon-response-overlay error'>
        <div class='overlay-header'>⚠️ Invalid Gluon Response</div>
        <div class='overlay-body'>
            <p>${data.message}</p>
            ${detailsHtml}
        </div>
        <div class='overlay-actions'>
            <button class='gluon-btn-ignore'>✗ Dismiss</button>
        </div>
    </div>`;
}