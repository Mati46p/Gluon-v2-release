import { backgroundLogger } from '../common/logger.js';

let ws = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY = 2000;
const pendingRequests = new Map();
const pendingFileAttachments = new Map();
let licenseCheckInterval = null; 

function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    backgroundLogger.log("WebSocket is already open or connecting.");
    broadcastStatus();
    return;
  }

  ws = new WebSocket('ws://127.0.0.1:8743');

  ws.onopen = () => {
    backgroundLogger.log("WebSocket Connected to Desktop.");
    reconnectAttempts = 0;
    broadcastStatus();

    clearInterval(licenseCheckInterval); // Clear any old interval
    licenseCheckInterval = setInterval(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        sendMessageToDesktop('get_license_status');
      }
    }, 10000);
  };

  ws.onmessage = (event) => {
    // backgroundLogger.log('Background received from desktop:', event.data);
    try {
      const response = JSON.parse(event.data);
      
      if (response.request_id && pendingRequests.has(response.request_id)) {
        const { timeout } = pendingRequests.get(response.request_id);
        clearTimeout(timeout);
        pendingRequests.delete(response.request_id);
        // backgroundLogger.log(`Cleared timeout for request: ${response.request_id}`);
      }

      // Route response based on action
      switch (response.action) {
        case 'get_license_status':
          chrome.runtime.sendMessage({ 
              type: 'license_status_loaded', 
              data: response.payload 
          });
          break;

        case 'get_projects':
          chrome.runtime.sendMessage({ type: 'projects_loaded', data: response.payload, request_id: response.request_id });
          break;
        case 'get_file_trees':
          chrome.runtime.sendMessage({ type: 'file_trees_loaded', data: response.payload, request_id: response.request_id });
          break;
        case 'get_files_multi':
          chrome.runtime.sendMessage({ type: 'files_multi_content_loaded', data: response.payload, request_id: response.request_id });
          break;
        case 'context_file_generated':
          chrome.runtime.sendMessage({ type: 'context_file_generated', data: response.payload, request_id: response.request_id });
          break;
        case 'get_environments':
          chrome.runtime.sendMessage({
            type: 'environments_loaded',
            data: response.payload,
            request_id: response.request_id
          });
          break;
        case 'get_environment_for_project':
          backgroundLogger.log('Received project environment from backend:', response.payload);
          chrome.runtime.sendMessage({
            type: 'project_environment_loaded',
            data: response.payload,
            request_id: response.request_id
          });
          break;
        case 'get_context_files_history':
          chrome.runtime.sendMessage({ 
            type: 'context_history_loaded', 
            data: response.payload, 
            request_id: response.request_id 
          });
          break;
        case 'context_file_content_loaded':
          // Pobierz filename z cache
          const filename = pendingFileAttachments.get(response.request_id) || 'context.txt';
          pendingFileAttachments.delete(response.request_id);
          
          // Przekaż do sidebara
          chrome.runtime.sendMessage({ 
            type: 'context_file_content_ready', 
            data: {
              filename: filename,
              content: response.payload.content
            },
            request_id: response.request_id 
          });
          break;
        // w funkcji ws.onmessage, w bloku switch
        case 'file_as_base64_loaded':
          backgroundLogger.log('Received binary file from desktop. Forwarding to content script.');
          // Forward binary file data to content script on active tab
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs.length > 0) {
              const activeTabId = tabs[0].id;
              backgroundLogger.log(`Found active tab with ID: ${activeTabId}. Sending message...`); // <-- DODAJ TEN LOG
              chrome.tabs.sendMessage(activeTabId, {
                action: 'upload_binary_file_to_ai',
                payload: response.payload
              }, (response) => {
                // Sprawdź, czy wystąpił błąd podczas wysyłania
                if (chrome.runtime.lastError) {
                  backgroundLogger.error('FATAL: Error sending message to content script:', chrome.runtime.lastError.message); // <-- DODAJ TEN LOG
                  chrome.runtime.sendMessage({ type: 'error', message: 'Could not communicate with the page. Please refresh the Gemini/Claude tab.' });
                  return;
                }
                // Sprawdź, czy content script odpowiedział z błędem
                if (response && !response.success) {
                    backgroundLogger.error('Content script responded with an error:', response.error); // <-- DODAJ TEN LOG
                } else {
                    backgroundLogger.log('Message successfully sent to content script.'); // <-- DODAJ TEN LOG
                }
              });
            } else {
              backgroundLogger.error('No active tab found to inject binary file.');
            }
          });
          break;
        case 'toggle_context_favorite':
          // Wyślij potwierdzenie do sidebara
          chrome.runtime.sendMessage({ 
            type: 'context_favorite_updated', 
            data: response.payload,
            request_id: response.request_id 
          });
          break;
          
        case 'rename_context_file':
          // Wyślij potwierdzenie do sidebara
          chrome.runtime.sendMessage({ 
            type: 'context_file_renamed', 
            data: response.payload,
            request_id: response.request_id 
          });
          break;

        case 'find_in_editor_ack':
          // To jest potwierdzenie z backendu, że polecenie zostało pomyślnie
          // przekazane do VS Code. Timeout został już anulowany wcześniej.
          // Logujemy i nie robimy nic więcej.
          backgroundLogger.log('Acknowledged: find_in_editor command was forwarded.');
          break;

        case 'error':
          backgroundLogger.error('Error from desktop:', response.payload);
          // NEW: Check for specific license error to re-lock the UI
          if (typeof response.payload === 'string' && response.payload.toLowerCase().includes('license is required')) {
              chrome.runtime.sendMessage({ type: 'license_status_loaded', data: { status: 'INVALID' } });
          }
          chrome.runtime.sendMessage({ type: 'error', message: response.payload, request_id: response.request_id });
          break;
        default:
          backgroundLogger.warn('Unknown action from desktop:', response.action);
      }
    } catch (e) {
      backgroundLogger.error('Error parsing message from desktop:', e);
    }
  };

  ws.onerror = (error) => {
    backgroundLogger.error('Background WebSocket error:', error);
    ws = null;
    broadcastStatus();
  };

  ws.onclose = () => {
    backgroundLogger.log("WebSocket Disconnected from Desktop.");
    clearInterval(licenseCheckInterval); // NEW: Stop checking on disconnect
    ws = null;
    broadcastStatus();
    if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
      reconnectAttempts++;
      const delay = RECONNECT_DELAY * Math.pow(2, reconnectAttempts - 1);
      backgroundLogger.log(`Attempting reconnect ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS} in ${delay}ms`);
      setTimeout(() => connect(), delay);
    }
  };
}

function broadcastStatus() {
  let status = 'Disconnected';
  if (ws) {
    switch (ws.readyState) {
      case WebSocket.CONNECTING: status = 'Connecting...'; break;
      case WebSocket.OPEN: status = 'Connected ✓'; break;
      case WebSocket.CLOSING: status = 'Closing...'; break;
      case WebSocket.CLOSED: default: status = 'Disconnected'; break;
    }
  }
  backgroundLogger.log(`Broadcasting status: ${status}`);
  chrome.runtime.sendMessage({ type: 'status_update', status: status });
}

function sendMessageToDesktop(action, payload = {}) {
  //backgroundLogger.log('Attempting to send')${action}'... WS state: ${ws ? ws.readyState : 'null'}`);
  if (ws && ws.readyState === WebSocket.OPEN) {
    const message = {
      id: crypto.randomUUID(),
      action: action,
      payload: payload
    };
    
    // Setup timeout (longer for file generation)
    const timeoutDuration = action === 'generate_context_file' ? 30000 : 15000;
    const timeout = setTimeout(() => {
      backgroundLogger.error(`Request ${message.id} timed out after ${timeoutDuration / 1000}s`);
      chrome.runtime.sendMessage({ type: 'error', message: 'Request timeout. The desktop app is not responding.', request_id: message.id });
      pendingRequests.delete(message.id);
    }, timeoutDuration);

    pendingRequests.set(message.id, { timeout });
    //backgroundLogger.log('Sending message object:'), message); 
    ws.send(JSON.stringify(message));
    // backgroundLogger.log(`Background sent '${action}' request to desktop with ID: ${message.id}`);
    return message.id; 
  } else {
    backgroundLogger.warn(`FAILED to send '${action}'. WebSocket is not open.`); 
    chrome.runtime.sendMessage({ type: 'error', message: 'Cannot send message, WebSocket is not open.' });
    return null;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let requestId;
  switch (message.action) {
    case 'get_projects':
      requestId = sendMessageToDesktop('get_projects');
      break;
    case 'select_files':
      // Przekaż komendę do sidebar (z content script)
      chrome.runtime.sendMessage({
        type: 'gluon_command_detected',
        action: 'select_files',
        files: message.files,
        clearPrevious: message.clearPrevious !== false
      });
      sendResponse({ success: true });
      break;
      
    case 'get_file_trees':
      requestId = sendMessageToDesktop('get_file_trees', { paths: message.payload.paths });
      break;
    case 'get_files_multi':
      requestId = sendMessageToDesktop('get_files_multi', { projects: message.payload.projects });
      break;
    case 'generate_context_file':
      requestId = sendMessageToDesktop('generate_context_file', message.payload);
      break;
    case 'get_environments':
      requestId = sendMessageToDesktop('get_environments');
      break;
    case 'get_environment_for_project':
      requestId = sendMessageToDesktop('get_environment_for_project', { path: message.payload.path });
      break;
    case 'get_context_files_history':
      requestId = sendMessageToDesktop('get_context_files_history', message.payload || {});
      break;
    case 'get_context_file_content':
      requestId = sendMessageToDesktop('get_context_file_content', { filepath: message.payload.filepath });
      // Zapamiętaj filename dla późniejszego użycia
      if (requestId) {
        pendingFileAttachments.set(requestId, message.payload.filename);
      }
      break;
    case 'get_binary_file_for_upload':
      backgroundLogger.log('Received "get_binary_file_for_upload". Forwarding to desktop...', message.payload); // <-- DODAJ TEN LOG
      requestId = sendMessageToDesktop('get_file_as_base64', { filepath: message.payload.filepath });
      break;
    case 'toggle_context_favorite':
      requestId = sendMessageToDesktop('toggle_context_favorite', {
        filepath: message.payload.filepath,
        favorite: message.payload.favorite
      });
      break;
      
    case 'rename_context_file':
      requestId = sendMessageToDesktop('rename_context_file', {
        filepath: message.payload.filepath,
        newName: message.payload.newName
      });
      break;

    case 'inject_file_to_gemini':
      // Forward file data to content script on active tab
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs || tabs.length === 0) {
          chrome.runtime.sendMessage({ 
            type: 'error', 
            message: 'No active tab found' 
          });
          return;
        }
        
        const activeTab = tabs[0];
        
        // Check if we're on supported AI platform
        const supportedPlatforms = [
          'gemini.google.com',
          'aistudio.google.com',
          'claude.ai'
        ];
        
        const isSupported = supportedPlatforms.some(platform => 
          activeTab.url?.includes(platform)
        );
        
        if (!isSupported) {
          chrome.runtime.sendMessage({ 
            type: 'error', 
            message: 'Please navigate to Claude, Gemini, or AI Studio first' 
          });
          return;
        }
        
        // Send message to content script
        chrome.tabs.sendMessage(activeTab.id, {
          action: 'upload_file_to_gemini',
          file: message.payload
        }, (response) => {
          if (chrome.runtime.lastError) {
            backgroundLogger.error('Failed to inject file:', chrome.runtime.lastError);
            chrome.runtime.sendMessage({ 
              type: 'error', 
              message: 'Content script not loaded. Please refresh the AI Studio page.' 
            });
          } else if (response && !response.success) {
            chrome.runtime.sendMessage({ 
              type: 'error', 
              message: response.error 
            });
          }
        });
      });
      break;
    case 'paste_prompt':
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0) {
          const activeTab = tabs[0];
          
          // CRITICAL STEP: First, ensure the tab is focused before sending the message.
          chrome.tabs.update(activeTab.id, { active: true }, () => {
            // After focusing the tab, give it a moment, then send the message to paste.
            setTimeout(() => {
              chrome.tabs.sendMessage(activeTab.id, {
                action: 'paste_prompt_to_input',
                payload: message.payload
              }, (response) => {
                if (chrome.runtime.lastError) {
                  backgroundLogger.error('Paste prompt error:', chrome.runtime.lastError.message);
                  chrome.runtime.sendMessage({ type: 'error', message: 'Failed to communicate with the page. Please refresh.' });
                } else if (response && !response.success) {
                  chrome.runtime.sendMessage({ type: 'error', message: response.error });
                }
              });
            }, 150); // A small delay to ensure focus is registered by the browser.
          });
        } else {
          chrome.runtime.sendMessage({ type: 'error', message: 'No active tab found.' });
        }
      });
      break;
    case 'gluon_response_detected':
      // Forward from content script to sidebar
      chrome.runtime.sendMessage({ type: 'gluon_response_detected', payload: message.payload });
      break;
    case 'render_gluon_overlay':
      // Forward from sidebar to content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'render_gluon_overlay', payload: message.payload });
        }
      });
      break;
    case 'apply_gluon_selection':
       // Forward from content script to sidebar
      chrome.runtime.sendMessage({ type: 'apply_gluon_selection', payload: message.payload });
      break;
    case 'search_file_in_tree':
      // Forward from content script to sidebar
      chrome.runtime.sendMessage({ type: 'search_file_in_tree', payload: message.payload });
      break;
    case 'init_connection':
      if (!ws || ws.readyState === WebSocket.CLOSED) {
        connect();
      } else {
        broadcastStatus();
      }
      setTimeout(() => {
        sendMessageToDesktop('get_license_status');
        sendMessageToDesktop('get_projects');
        sendMessageToDesktop('get_environments');
      }, 250);
      break;
    case 'find_in_editor':
      backgroundLogger.log('Received "find_in_editor". Forwarding to desktop.', message.payload);
      requestId = sendMessageToDesktop('find_in_editor', {
          filePath: message.payload.filePath,
          searchText: message.payload.searchText,
      });
      break;

    default:
      backgroundLogger.warn('Unknown action from extension:', message.action);
  }
  sendResponse(requestId);
  return true;
});

connect();

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

setInterval(() => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    // backgroundLogger.log('Connection alive');
  }
}, 30000);